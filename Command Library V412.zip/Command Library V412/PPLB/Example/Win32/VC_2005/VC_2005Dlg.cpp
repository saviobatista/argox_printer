// VC_2005Dlg.cpp : ��@��
//

#include "stdafx.h"
#include "VC_2005.h"
#include "VC_2005Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

const char szSavePath[] = "C:\\Argox";
const char szSaveFile[] = "C:\\Argox\\PPLB_Example.Prn";
const char sznop1[]     = "nop_front\r\n";
const char sznop2[]     = "nop_middle\r\n";
// PPLBDLL Function Declaration start
HINSTANCE hPPLB;
typedef int   (_stdcall *pfnB_Bar2d_Maxi)(int x, int y, int cl, int cc, int pc, LPCTSTR data);
typedef int   (_stdcall *pfnB_Bar2d_PDF417)(int x, int y, int w, int v, int s, int c, int px,
						 int py, int r, int l, int t, int o, LPCTSTR data);
typedef int   (_stdcall *pfnB_Bar2d_PDF417_N)(int x, int y, int w, int h, LPCTSTR pParameter,
						 LPCTSTR data);
typedef int   (_stdcall *pfnB_Bar2d_DataMatrix)(int x, int y, int r, int l, int h, int v, LPCTSTR data);
typedef void  (_stdcall *pfnB_ClosePrn)(void);
typedef int   (_stdcall *pfnB_CreatePrn)(int selection, LPCTSTR filename);
typedef int   (_stdcall *pfnB_Del_Form)(char formname[10]);
typedef int   (_stdcall *pfnB_Del_Pcx)(char pcxname[10]);
typedef int   (_stdcall *pfnB_Draw_Box)(int x, int y, int thickness, int hor_dots, int ver_dots);
typedef int   (_stdcall *pfnB_Draw_Line)(char mode, int x, int y, int hor_dots, int ver_dots);
typedef int   (_stdcall *pfnB_Error_Reporting)(char option);
typedef char* (_stdcall *pfnB_Get_DLL_Version)(int nShowMessage);
typedef int   (_stdcall *pfnB_Get_DLL_VersionA)(int nShowMessage);
typedef int   (_stdcall *pfnB_Get_Graphic_ColorBMP)(int x, int y, LPCTSTR filename);
typedef int   (_stdcall *pfnB_Get_Graphic_ColorBMPEx)(int x, int y, int nWidth, int nHeight, 
						 int rotate, LPCTSTR id_name, LPCTSTR filename);
typedef int   (_stdcall *pfnB_Get_Graphic_ColorBMP_HBitmap)(int x, int y, int nWidth, int nHeight, 
						 int rotate, LPCTSTR id_name, HBITMAP hbm);
typedef int   (_stdcall *pfnB_Get_Pcx)(int x, int y, LPCTSTR filename);
typedef int   (_stdcall *pfnB_Initial_Setting)(int Type, LPCTSTR Source);
typedef int   (_stdcall *pfnB_WriteData)(int IsImmediate, LPCTSTR pbuf, DWORD length);
typedef int   (_stdcall *pfnB_ReadData)(LPTSTR pbuf, DWORD length, DWORD dwTimeoutms);
typedef int   (_stdcall *pfnB_Load_Pcx)(int x, int y, char pcxname[10]);
typedef int   (_stdcall *pfnB_Open_ChineseFont)(char* path);
typedef int   (_stdcall *pfnB_Print_Form)(int labset, int copies, char form_out[10], LPTSTR var);
typedef int   (_stdcall *pfnB_Print_MCopy)(int labset, int copies);
typedef int   (_stdcall *pfnB_Print_Out)(int labset);
typedef int   (_stdcall *pfnB_Prn_Barcode)(int x, int y, int ori, char type[4], int narrow, 
						 int width, int height, char human, LPCTSTR data);
typedef void  (_stdcall *pfnB_Prn_Configuration)(void);
typedef int   (_stdcall *pfnB_Prn_Text)(int x, int y, int ori, int font, int hor_factor,
						 int ver_factor, char mode, LPCTSTR data);
typedef int   (_stdcall *pfnB_Prn_Text_Chinese)(int x, int y, int fonttype, LPCTSTR id_name,
						 LPCTSTR data);
typedef int   (_stdcall *pfnB_Prn_Text_TrueType)(int x, int y, int FSize, LPCTSTR FType, int Fspin,
						 int FWeight, int FItalic, int FUnline, int FStrikeOut, LPCTSTR id_name,
						 LPCTSTR data);
typedef int   (_stdcall *pfnB_Prn_Text_TrueType_W)(int x, int y, int FHeight, int FWidth,
						 LPCTSTR FType, int Fspin, int FWeight, int FItalic, int FUnline,
						 int FStrikeOut, LPCTSTR id_name, LPCTSTR data);
typedef int   (_stdcall *pfnB_Select_Option)(int object);
typedef int   (_stdcall *pfnB_Select_Option2)(int object, int p);
typedef int   (_stdcall *pfnB_Select_Symbol)(int num_bit, int symbol, int country);
typedef int   (_stdcall *pfnB_Select_Symbol2)(int num_bit, char symbol[2], int country);
typedef int   (_stdcall *pfnB_Set_Backfeed)(char option);
typedef int   (_stdcall *pfnB_Set_Backfeed_Offset)(int offset);
typedef int   (_stdcall *pfnB_Set_CutPeel_Offset)(int offset);
typedef int   (_stdcall *pfnB_Set_BMPSave)(int nSave, char* pstrBMPFName);
typedef int   (_stdcall *pfnB_Set_Darkness)(int darkness);
typedef int   (_stdcall *pfnB_Set_DebugDialog)(int nEnable);
typedef int   (_stdcall *pfnB_Set_Direction)(char direction);
typedef int   (_stdcall *pfnB_Set_Form)(LPCTSTR formfile);
typedef int   (_stdcall *pfnB_Set_Labgap)(int lablength, int gaplength);
typedef int   (_stdcall *pfnB_Set_Labwidth)(int labwidth);
typedef int   (_stdcall *pfnB_Set_Originpoint)(int hor, int ver);
typedef int   (_stdcall *pfnB_Set_Prncomport)(int baud, char parity, int data, int stop);
typedef int   (_stdcall *pfnB_Set_Prncomport_PC)(int nBaudRate, int nByteSize, int nParity,
						 int nStopBits, int nDsr, int nCts, int nXonXoff);
typedef int   (_stdcall *pfnB_Set_Speed)(int speed);
typedef int   (_stdcall *pfnB_Set_ProcessDlg)(int nShow);
typedef int   (_stdcall *pfnB_Set_ErrorDlg)(int nShow);
typedef int   (_stdcall *pfnB_GetUSBBufferLen)(void);
typedef int   (_stdcall *pfnB_EnumUSB)(char *buf);
typedef int   (_stdcall *pfnB_CreateUSBPort)(int nPort);
typedef int   (_stdcall *pfnB_ResetPrinter)(void);
typedef int   (_stdcall *pfnB_GetPrinterResponse)(char *buf, int nMax);
typedef int   (_stdcall *pfnB_TFeedMode)(int nMode);
typedef int   (_stdcall *pfnB_TFeedTest)(void);
typedef int   (_stdcall *pfnB_CreatePort)(int nPortType, int nPort, LPCTSTR filename);
typedef int   (_stdcall *pfnB_Execute_Form)(char form_out[10], LPTSTR var);
typedef int   (_stdcall *pfnB_Bar2d_QR)(int x, int y, int model, int scl, char error, char dinput,
						 int c, int d, int p, LPCTSTR data);
typedef int   (_stdcall *pfnB_GetNetPrinterBufferLen)(void);
typedef int   (_stdcall *pfnB_EnumNetPrinter)(char *buf);
typedef int   (_stdcall *pfnB_CreateNetPort)(int nPort);
typedef int   (_stdcall *pfnB_Prn_Text_TrueType_Uni)(int x, int y, int FSize, LPCTSTR FType,
						 int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut,
						 LPCTSTR id_name, LPCWSTR data, int format);
typedef int   (_stdcall *pfnB_Prn_Text_TrueType_UniB)(int x, int y, int FSize, LPCTSTR FType,
						 int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut,
						 LPCTSTR id_name, LPCTSTR data, int format);										
typedef int   (_stdcall *pfnB_GetUSBDeviceInfo)(int nPort, char *pDeviceName, int *pDeviceNameLen,
						 char *pDevicePath, int *pDevicePathLen);
typedef int   (_stdcall *pfnB_Set_EncryptionKey)(char encryptionKey[16]);
typedef int   (_stdcall *pfnB_Check_EncryptionKey)(char decodeKey[8], char encryptionKey[16], 
						 DWORD dwTimeoutms);
typedef void  (_stdcall *pfnB_Set_CommTimeout)(int ReadTotalTimeoutConstant, int WriteTotalTimeoutConstant);
typedef void  (_stdcall *pfnB_Get_CommTimeout)(int *ReadTotalTimeoutConstant, int *WriteTotalTimeoutConstant);
typedef void  (_stdcall *pfnB_Set_LabelForSmartPrint)(int lablength, int gaplength);

pfnB_Bar2d_Maxi				B_Bar2d_Maxi			= NULL;
pfnB_Bar2d_PDF417			B_Bar2d_PDF417			= NULL;
pfnB_Bar2d_PDF417_N			B_Bar2d_PDF417_N		= NULL;
pfnB_Bar2d_DataMatrix		B_Bar2d_DataMatrix		= NULL;
pfnB_ClosePrn				B_ClosePrn				= NULL;
pfnB_CreatePrn				B_CreatePrn				= NULL;
pfnB_Del_Form				B_Del_Form				= NULL;
pfnB_Del_Pcx				B_Del_Pcx				= NULL;
pfnB_Draw_Box				B_Draw_Box				= NULL; 
pfnB_Draw_Line				B_Draw_Line				= NULL;
pfnB_Error_Reporting		B_Error_Reporting		= NULL;
pfnB_Get_DLL_Version		B_Get_DLL_Version		= NULL;
pfnB_Get_DLL_VersionA		B_Get_DLL_VersionA		= NULL;
pfnB_Get_Graphic_ColorBMP	B_Get_Graphic_ColorBMP	= NULL;
pfnB_Get_Graphic_ColorBMPEx	B_Get_Graphic_ColorBMPEx	= NULL;
pfnB_Get_Graphic_ColorBMP_HBitmap	B_Get_Graphic_ColorBMP_HBitmap	= NULL;
pfnB_Get_Pcx				B_Get_Pcx				= NULL;
pfnB_Initial_Setting		B_Initial_Setting		= NULL;
pfnB_WriteData				B_WriteData				= NULL;
pfnB_ReadData				B_ReadData				= NULL;
pfnB_Load_Pcx				B_Load_Pcx				= NULL;
pfnB_Open_ChineseFont		B_Open_ChineseFont		= NULL;
pfnB_Print_Form				B_Print_Form			= NULL;
pfnB_Print_MCopy			B_Print_MCopy			= NULL;
pfnB_Print_Out				B_Print_Out				= NULL;
pfnB_Prn_Barcode			B_Prn_Barcode			= NULL;
pfnB_Prn_Configuration		B_Prn_Configuration		= NULL;
pfnB_Prn_Text				B_Prn_Text				= NULL;
pfnB_Prn_Text_Chinese		B_Prn_Text_Chinese		= NULL;
pfnB_Prn_Text_TrueType		B_Prn_Text_TrueType		= NULL;
pfnB_Prn_Text_TrueType_W	B_Prn_Text_TrueType_W	= NULL;
pfnB_Select_Option			B_Select_Option			= NULL;
pfnB_Select_Option2			B_Select_Option2		= NULL;
pfnB_Select_Symbol			B_Select_Symbol			= NULL;
pfnB_Select_Symbol2			B_Select_Symbol2		= NULL;
pfnB_Set_Backfeed			B_Set_Backfeed			= NULL;
pfnB_Set_Backfeed_Offset	B_Set_Backfeed_Offset	= NULL;
pfnB_Set_CutPeel_Offset		B_Set_CutPeel_Offset	= NULL;
pfnB_Set_BMPSave			B_Set_BMPSave			= NULL;
pfnB_Set_Darkness			B_Set_Darkness			= NULL;
pfnB_Set_DebugDialog		B_Set_DebugDialog		= NULL;
pfnB_Set_Direction			B_Set_Direction			= NULL;
pfnB_Set_Form				B_Set_Form				= NULL;
pfnB_Set_Labgap				B_Set_Labgap			= NULL;
pfnB_Set_Labwidth			B_Set_Labwidth			= NULL;
pfnB_Set_Originpoint		B_Set_Originpoint		= NULL;
pfnB_Set_Prncomport			B_Set_Prncomport		= NULL;
pfnB_Set_Prncomport_PC		B_Set_Prncomport_PC		= NULL;
pfnB_Set_Speed				B_Set_Speed				= NULL;
pfnB_Set_ProcessDlg			B_Set_ProcessDlg		= NULL;
pfnB_Set_ErrorDlg			B_Set_ErrorDlg		= NULL;
pfnB_GetUSBBufferLen		B_GetUSBBufferLen		= NULL;
pfnB_EnumUSB				B_EnumUSB				= NULL;
pfnB_CreateUSBPort			B_CreateUSBPort			= NULL;
pfnB_ResetPrinter			B_ResetPrinter			= NULL;
pfnB_GetPrinterResponse		B_GetPrinterResponse	= NULL;
pfnB_TFeedMode				B_TFeedMode				= NULL;
pfnB_TFeedTest				B_TFeedTest				= NULL;
pfnB_CreatePort				B_CreatePort			= NULL;
pfnB_Execute_Form			B_Execute_Form			= NULL;
pfnB_Bar2d_QR				B_Bar2d_QR				= NULL;		
pfnB_GetNetPrinterBufferLen	B_GetNetPrinterBufferLen= NULL;
pfnB_EnumNetPrinter			B_EnumNetPrinter		= NULL;
pfnB_CreateNetPort			B_CreateNetPort			= NULL;
pfnB_Prn_Text_TrueType_Uni	B_Prn_Text_TrueType_Uni = NULL;
pfnB_Prn_Text_TrueType_UniB	B_Prn_Text_TrueType_UniB= NULL;
pfnB_GetUSBDeviceInfo		B_GetUSBDeviceInfo		= NULL;
pfnB_Set_EncryptionKey		B_Set_EncryptionKey		= NULL;
pfnB_Check_EncryptionKey	B_Check_EncryptionKey	= NULL;
pfnB_Set_CommTimeout		B_Set_CommTimeout		= NULL;
pfnB_Get_CommTimeout		B_Get_CommTimeout		= NULL;
pfnB_Set_LabelForSmartPrint	B_Set_LabelForSmartPrint	= NULL;
// PPLBDLL Function Declaration end

// CVC_2005Dlg ��ܤ��

CVC_2005Dlg::CVC_2005Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVC_2005Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	// Load Library start
	VERIFY(hPPLB = ::LoadLibrary("WINPPLB.DLL"));
	VERIFY(B_Bar2d_Maxi = (pfnB_Bar2d_Maxi) ::GetProcAddress(hPPLB,"B_Bar2d_Maxi"));
	VERIFY(B_Bar2d_PDF417 = (pfnB_Bar2d_PDF417) ::GetProcAddress(hPPLB,"B_Bar2d_PDF417"));
	VERIFY(B_Bar2d_PDF417_N = (pfnB_Bar2d_PDF417_N) ::GetProcAddress(hPPLB,"B_Bar2d_PDF417_N"));
	VERIFY(B_Bar2d_DataMatrix = (pfnB_Bar2d_DataMatrix) ::GetProcAddress(hPPLB,"B_Bar2d_DataMatrix"));
	VERIFY(B_ClosePrn = (pfnB_ClosePrn) ::GetProcAddress(hPPLB,"B_ClosePrn"));
	VERIFY(B_CreatePrn = (pfnB_CreatePrn) ::GetProcAddress(hPPLB,"B_CreatePrn"));
	VERIFY(B_Del_Form = (pfnB_Del_Form) ::GetProcAddress(hPPLB,"B_Del_Form"));
	VERIFY(B_Del_Pcx = (pfnB_Del_Pcx) ::GetProcAddress(hPPLB,"B_Del_Pcx"));
	VERIFY(B_Draw_Box = (pfnB_Draw_Box) ::GetProcAddress(hPPLB,"B_Draw_Box"));
	VERIFY(B_Draw_Line = (pfnB_Draw_Line) ::GetProcAddress(hPPLB,"B_Draw_Line"));
	VERIFY(B_Error_Reporting = (pfnB_Error_Reporting) ::GetProcAddress(hPPLB,"B_Error_Reporting"));
	VERIFY(B_Get_DLL_Version = (pfnB_Get_DLL_Version) ::GetProcAddress(hPPLB,"B_Get_DLL_Version"));
	VERIFY(B_Get_DLL_VersionA = (pfnB_Get_DLL_VersionA) ::GetProcAddress(hPPLB,"B_Get_DLL_VersionA"));
	VERIFY(B_Get_Graphic_ColorBMP = (pfnB_Get_Graphic_ColorBMP) ::GetProcAddress(hPPLB,"B_Get_Graphic_ColorBMP"));
	VERIFY(B_Get_Graphic_ColorBMPEx = (pfnB_Get_Graphic_ColorBMPEx) ::GetProcAddress(hPPLB,"B_Get_Graphic_ColorBMPEx"));
	VERIFY(B_Get_Graphic_ColorBMP_HBitmap = (pfnB_Get_Graphic_ColorBMP_HBitmap) ::GetProcAddress(hPPLB,"B_Get_Graphic_ColorBMP_HBitmap"));
	VERIFY(B_Get_Pcx = (pfnB_Get_Pcx) ::GetProcAddress(hPPLB,"B_Get_Pcx"));
	VERIFY(B_Initial_Setting = (pfnB_Initial_Setting) ::GetProcAddress(hPPLB,"B_Initial_Setting"));
	VERIFY(B_WriteData = (pfnB_WriteData) ::GetProcAddress(hPPLB,"B_WriteData"));
	VERIFY(B_ReadData = (pfnB_ReadData) ::GetProcAddress(hPPLB,"B_ReadData"));
	VERIFY(B_Load_Pcx = (pfnB_Load_Pcx) ::GetProcAddress(hPPLB,"B_Load_Pcx"));
	VERIFY(B_Open_ChineseFont = (pfnB_Open_ChineseFont) ::GetProcAddress(hPPLB,"B_Open_ChineseFont"));
	VERIFY(B_Print_Form = (pfnB_Print_Form) ::GetProcAddress(hPPLB,"B_Print_Form"));
	VERIFY(B_Print_MCopy = (pfnB_Print_MCopy) ::GetProcAddress(hPPLB,"B_Print_MCopy"));
	VERIFY(B_Print_Out = (pfnB_Print_Out) ::GetProcAddress(hPPLB,"B_Print_Out"));
	VERIFY(B_Prn_Barcode = (pfnB_Prn_Barcode) ::GetProcAddress(hPPLB,"B_Prn_Barcode"));
	VERIFY(B_Prn_Configuration = (pfnB_Prn_Configuration) ::GetProcAddress(hPPLB,"B_Prn_Configuration"));
	VERIFY(B_Prn_Text = (pfnB_Prn_Text) ::GetProcAddress(hPPLB,"B_Prn_Text"));
	VERIFY(B_Prn_Text_Chinese = (pfnB_Prn_Text_Chinese) ::GetProcAddress(hPPLB,"B_Prn_Text_Chinese"));
	VERIFY(B_Prn_Text_TrueType = (pfnB_Prn_Text_TrueType) ::GetProcAddress(hPPLB,"B_Prn_Text_TrueType"));
	VERIFY(B_Prn_Text_TrueType_W = (pfnB_Prn_Text_TrueType_W) ::GetProcAddress(hPPLB,"B_Prn_Text_TrueType_W"));
	VERIFY(B_Select_Option = (pfnB_Select_Option) ::GetProcAddress(hPPLB,"B_Select_Option"));
	VERIFY(B_Select_Option2 = (pfnB_Select_Option2) ::GetProcAddress(hPPLB,"B_Select_Option2"));
	VERIFY(B_Select_Symbol = (pfnB_Select_Symbol) ::GetProcAddress(hPPLB,"B_Select_Symbol"));
	VERIFY(B_Select_Symbol2 = (pfnB_Select_Symbol2) ::GetProcAddress(hPPLB,"B_Select_Symbol2"));
	VERIFY(B_Set_Backfeed = (pfnB_Set_Backfeed) ::GetProcAddress(hPPLB,"B_Set_Backfeed"));
	VERIFY(B_Set_Backfeed_Offset = (pfnB_Set_Backfeed_Offset) ::GetProcAddress(hPPLB,"B_Set_Backfeed_Offset"));
	VERIFY(B_Set_CutPeel_Offset = (pfnB_Set_CutPeel_Offset) ::GetProcAddress(hPPLB,"B_Set_CutPeel_Offset"));
	VERIFY(B_Set_BMPSave = (pfnB_Set_BMPSave) ::GetProcAddress(hPPLB,"B_Set_BMPSave"));
	VERIFY(B_Set_Darkness = (pfnB_Set_Darkness) ::GetProcAddress(hPPLB,"B_Set_Darkness"));
	VERIFY(B_Set_DebugDialog = (pfnB_Set_DebugDialog) ::GetProcAddress(hPPLB,"B_Set_DebugDialog"));
	VERIFY(B_Set_Direction = (pfnB_Set_Direction) ::GetProcAddress(hPPLB,"B_Set_Direction"));
	VERIFY(B_Set_Form = (pfnB_Set_Form) ::GetProcAddress(hPPLB,"B_Set_Form"));
	VERIFY(B_Set_Labgap = (pfnB_Set_Labgap) ::GetProcAddress(hPPLB,"B_Set_Labgap"));
	VERIFY(B_Set_Labwidth = (pfnB_Set_Labwidth) ::GetProcAddress(hPPLB,"B_Set_Labwidth"));
	VERIFY(B_Set_Originpoint = (pfnB_Set_Originpoint) ::GetProcAddress(hPPLB,"B_Set_Originpoint"));
	VERIFY(B_Set_Prncomport = (pfnB_Set_Prncomport) ::GetProcAddress(hPPLB,"B_Set_Prncomport"));
	VERIFY(B_Set_Prncomport_PC = (pfnB_Set_Prncomport_PC) ::GetProcAddress(hPPLB,"B_Set_Prncomport_PC"));
	VERIFY(B_Set_Speed = (pfnB_Set_Speed) ::GetProcAddress(hPPLB,"B_Set_Speed"));
	VERIFY(B_Set_ProcessDlg = (pfnB_Set_ProcessDlg) ::GetProcAddress(hPPLB,"B_Set_ProcessDlg"));
	VERIFY(B_Set_ErrorDlg = (pfnB_Set_ErrorDlg) ::GetProcAddress(hPPLB,"B_Set_ErrorDlg"));
	VERIFY(B_GetUSBBufferLen = (pfnB_GetUSBBufferLen) ::GetProcAddress(hPPLB,"B_GetUSBBufferLen"));
	VERIFY(B_EnumUSB = (pfnB_EnumUSB) ::GetProcAddress(hPPLB,"B_EnumUSB"));
	VERIFY(B_CreateUSBPort = (pfnB_CreateUSBPort) ::GetProcAddress(hPPLB,"B_CreateUSBPort"));
	VERIFY(B_ResetPrinter = (pfnB_ResetPrinter) ::GetProcAddress(hPPLB,"B_ResetPrinter"));
	VERIFY(B_GetPrinterResponse = (pfnB_GetPrinterResponse) ::GetProcAddress(hPPLB, "B_GetPrinterResponse"));
	VERIFY(B_TFeedMode = (pfnB_TFeedMode) ::GetProcAddress(hPPLB, "B_TFeedMode"));
	VERIFY(B_TFeedTest = (pfnB_TFeedTest) ::GetProcAddress(hPPLB, "B_TFeedTest"));
	VERIFY(B_CreatePort = (pfnB_CreatePort) ::GetProcAddress(hPPLB, "B_CreatePort"));
	VERIFY(B_Execute_Form = (pfnB_Execute_Form) ::GetProcAddress(hPPLB, "B_Execute_Form"));
	VERIFY(B_Bar2d_QR = (pfnB_Bar2d_QR) ::GetProcAddress(hPPLB,"B_Bar2d_QR"));
	VERIFY(B_GetNetPrinterBufferLen = (pfnB_GetNetPrinterBufferLen) ::GetProcAddress(hPPLB,"B_GetNetPrinterBufferLen"));
	VERIFY(B_EnumNetPrinter = (pfnB_EnumNetPrinter) ::GetProcAddress(hPPLB,"B_EnumNetPrinter"));
	VERIFY(B_CreateNetPort = (pfnB_CreateNetPort) ::GetProcAddress(hPPLB,"B_CreateNetPort"));
	VERIFY(B_Prn_Text_TrueType_Uni = (pfnB_Prn_Text_TrueType_Uni) ::GetProcAddress(hPPLB,"B_Prn_Text_TrueType_Uni"));
	VERIFY(B_Prn_Text_TrueType_UniB = (pfnB_Prn_Text_TrueType_UniB) ::GetProcAddress(hPPLB,"B_Prn_Text_TrueType_UniB"));
	VERIFY(B_GetUSBDeviceInfo = (pfnB_GetUSBDeviceInfo) ::GetProcAddress(hPPLB,"B_GetUSBDeviceInfo"));
	VERIFY(B_Set_EncryptionKey = (pfnB_Set_EncryptionKey) ::GetProcAddress(hPPLB,"B_Set_EncryptionKey"));
	VERIFY(B_Check_EncryptionKey = (pfnB_Check_EncryptionKey) ::GetProcAddress(hPPLB,"B_Check_EncryptionKey"));
	VERIFY(B_Set_CommTimeout = (pfnB_Set_CommTimeout) ::GetProcAddress(hPPLB,"B_Set_CommTimeout"));
	VERIFY(B_Get_CommTimeout = (pfnB_Get_CommTimeout) ::GetProcAddress(hPPLB,"B_Get_CommTimeout"));
	VERIFY(B_Set_LabelForSmartPrint = (pfnB_Set_LabelForSmartPrint) ::GetProcAddress(hPPLB,"B_Set_LabelForSmartPrint"));
	// Load Library end
}

CVC_2005Dlg::~CVC_2005Dlg()
{
	VERIFY(::FreeLibrary(hPPLB));
}

void CVC_2005Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CVC_2005Dlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CVC_2005Dlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CVC_2005Dlg �T���B�z�`��

BOOL CVC_2005Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	//ShowWindow(SW_MINIMIZE);

	// TODO: �b���[�J�B�~����l�]�w

	return TRUE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CVC_2005Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CVC_2005Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CVC_2005Dlg::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	// open port.
	int nLen, ret, sw;
	char *ver, *pbuf = new char[128];
	CString strmsg;

	// dll version.
	ver = B_Get_DLL_Version(0);

	// search port.
	nLen = B_GetUSBBufferLen() + 1;
	strmsg.Format("DLL %s\r\n", ver);
	if (nLen > 1)
	{
		char *buf1,*buf2;
		int len1 = 128, len2 = 128;
		buf1 = new char[len1];
		buf2 = new char[len2];
		B_EnumUSB(pbuf);
		B_GetUSBDeviceInfo(1, buf1, &len1, buf2, &len2);
		sw = 1;
		if (sw) {
			ret = B_CreatePrn(12, buf2);// open usb.
		}
		else {
			ret = B_CreateUSBPort(1);// must call B_GetUSBBufferLen() function first.
		}
		if (0 != ret) {
			strmsg += "Open USB fail!";
		}
		else {
			strmsg += "Open USB:\r\nDevice name: ";
			strmsg += buf1;
			strmsg += "\r\nDevice path: ";
			strmsg += buf2;
			//sw = 2;
			if (2 == sw) {
				//Immediate Error Report.
				B_WriteData(1, "^ee\r\n", 5);//^ee
				ret = B_ReadData(pbuf, 4, 1000);
			}
		}
	}
	else
	{
		CreateDirectory(szSavePath, NULL);
		ret = B_CreatePrn(0, szSaveFile);// open file.
		strmsg += "Open ";
		strmsg += szSaveFile;
		if (0 != ret) {
			strmsg += " file fail!";
		}
		else {
			strmsg += " file succeed!";
		}
	}
	MessageBox(strmsg);
	if (0 != ret)
		return;

	// sample setting.
	B_Set_DebugDialog(1);
	B_Set_Originpoint(0,0);
	B_Select_Option(2);
	B_Set_Darkness(8);
	B_Del_Pcx("*");// delete all picture.
	B_WriteData(0, sznop2, (DWORD)strlen(sznop2));
	B_WriteData(1, sznop1, (DWORD)strlen(sznop1));
	//When using standard label, and the printer is Intelli Print mode or Smart Print mode,
	//When calling this function and giving the correct label information,
	//the immediate print function will be enabled according to the label length setting.
	B_Set_LabelForSmartPrint(254*3, 30);//label information: length= 3 * 25.4 mm, gap= 3 mm.

	//draw box.
	B_Draw_Box(20, 20, 4, 760, 560);
	B_Draw_Line('O', 400, 20, 4, 540);

	//print text, true type text.
	B_Prn_Text(30, 40, 0, 2, 1, 1, 'N', "PPLB Lib Example");
	B_Prn_Text_TrueType(30,100,30,"Arial",1,400,0,0,0,"AA","TrueType Font");//save in printer.
	B_Prn_Text_TrueType_W(30,160,20,20,"Times New Roman",1,400,0,0,0,"AB","TT_W: �h�r������");
	B_Prn_Text_TrueType_Uni(30,220,30,"Times New Roman",1,400,0,0,0,"AC",L"TT_Uni: �h�r������",1);//UTF-16
	strcpy(pbuf, "\xFF\xFE");//UTF-16.
	memcpy(&pbuf[2], (char *)L"TT_UniB: �h�r������", 15*2);//copy mutil byte.
	B_Prn_Text_TrueType_UniB(30,280,30,"Times New Roman",1,400,0,0,0,"AD",pbuf,0);//Byte Order Mark.

	//barcode.
	B_Prn_Barcode(420, 100, 0, "3", 2, 3, 40, 'B', "1234<+1>");//have a counter
	B_Bar2d_QR(420, 200, 1, 3, 'M', 'A', 0, 0, 0, "QR CODE");

	//picture.
	B_Get_Graphic_ColorBMP(420, 280, "bb.bmp");// Color bmp file.
	B_Get_Graphic_ColorBMPEx(420, 320, 200, 150, 2, "bb1", "bb.bmp");//180 angle.
	HANDLE himage = LoadImage(NULL,"bb.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
	B_Get_Graphic_ColorBMP_HBitmap(630, 280, 250, 80, 1, "bb2", (HBITMAP)himage);//90 angle.
	if (himage)
		DeleteObject(himage);

	// output.
	B_Print_Out(2);// copy 2.

	// close port.
	B_ClosePrn();
}
