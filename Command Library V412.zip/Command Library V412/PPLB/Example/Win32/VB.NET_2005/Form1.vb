Public Class Form1
    Const IMAGE_BITMAP = 0
    Const LR_LOADFROMFILE = &H10
    Private Declare Function LoadImage Lib "user32" Alias "LoadImageA" (ByVal hInst As Integer, _
            ByVal lpsz As String, ByVal un1 As Integer, ByVal n1 As Integer, ByVal n2 As Integer, _
            ByVal un2 As Integer) As Integer
    Private Declare Function DeleteObject Lib "Gdi32" (ByVal ho As Integer) As Integer
    Const szSavePath As String = "C:\Argox"
    Const szSaveFile As String = "C:\Argox\PPLB_Example.Prn"
    Const sznop1 As String = "nop_front" + vbCrLf
    Const sznop2 As String = "nop_middle" + vbCrLf
    Private Declare Function B_Bar2d_Maxi Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal cl As Integer, ByVal cc As Integer, ByVal pc As Integer, ByVal data As String) As Integer
    Private Declare Function B_Bar2d_PDF417 Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal w As Integer, ByVal v As Integer, ByVal s As Integer, ByVal c As Integer, _
            ByVal px As Integer, ByVal py As Integer, ByVal r As Integer, ByVal l As Integer, _
            ByVal t As Integer, ByVal o As Integer, ByVal data As String) As Integer
    Private Declare Function B_Bar2d_PDF417_N Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal w As Integer, ByVal h As Integer, ByVal pParameter As String, ByVal data As String) As Integer
    Private Declare Function B_Bar2d_DataMatrix Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal r As Integer, ByVal l As Integer, ByVal h As Integer, ByVal v As Integer, _
            ByVal data As String) As Integer
    Private Declare Sub B_ClosePrn Lib "WINPPLB.DLL" ()
    Private Declare Function B_CreatePrn Lib "WINPPLB.DLL" (ByVal selection As Integer, _
            ByVal filename As String) As Integer
    Private Declare Function B_Del_Form Lib "WINPPLB.DLL" (ByVal formname As String) As Integer
    Private Declare Function B_Del_Pcx Lib "WINPPLB.DLL" (ByVal pcxname As String) As Integer
    Private Declare Function B_Draw_Box Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal thickness As Integer, ByVal hor_dots As Integer, ByVal ver_dots As Integer) As Integer
    Private Declare Function B_Draw_Line Lib "WINPPLB.DLL" (ByVal mode As Byte, ByVal x As Integer, _
            ByVal y As Integer, ByVal hor_dots As Integer, ByVal ver_dots As Integer) As Integer
    Private Declare Function B_Error_Reporting Lib "WINPPLB.DLL" (ByVal options As Byte) As Integer
    Private Declare Function B_Get_DLL_Version Lib "WINPPLB.DLL" (ByVal nShowMessage As Integer) As String
    Private Declare Function B_Get_DLL_VersionA Lib "WINPPLB.DLL" (ByVal nShowMessage As Integer) As Integer
    Private Declare Function B_Get_Graphic_ColorBMP Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal filename As String) As Integer
    Private Declare Function B_Get_Graphic_ColorBMPEx Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal id_name As String, ByVal filename As String) As Integer
    Private Declare Function B_Get_Graphic_ColorBMP_HBitmap Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal id_name As String, ByVal hbm As Integer) As Integer
    Private Declare Function B_Get_Pcx Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal filename As String) As Integer
    Private Declare Function B_Initial_Setting Lib "WINPPLB.DLL" (ByVal TType As Integer, _
            ByVal Source As String) As Integer
    Private Declare Function B_WriteData Lib "WINPPLB.DLL" (ByVal IsImmediate As Integer, _
            ByVal pbuf As Byte(), ByVal length As ULong) As Integer
    Private Declare Function B_ReadData Lib "WINPPLB.DLL" (ByVal pbuf As Byte(), ByVal length As ULong, _
            ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function B_Load_Pcx Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal pcxname As String) As Integer
    Private Declare Function B_Open_ChineseFont Lib "WINPPLB.DLL" (ByVal path As String) As Integer
    Private Declare Function B_Print_Form Lib "WINPPLB.DLL" (ByVal labset As Integer, _
            ByVal copies As Integer, ByVal form_out As String, ByVal var As String) As Integer
    Private Declare Function B_Print_MCopy Lib "WINPPLB.DLL" (ByVal labset As Integer, _
            ByVal copies As Integer) As Integer
    Private Declare Function B_Print_Out Lib "WINPPLB.DLL" (ByVal labset As Integer) As Integer
    Private Declare Function B_Prn_Barcode Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal TType As String, ByVal narrow As Integer, ByVal width As Integer, _
            ByVal height As Integer, ByVal human As Byte, ByVal data As String) As Integer
    Private Declare Sub B_Prn_Configuration Lib "WINPPLB.DLL" ()
    Private Declare Function B_Prn_Text Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal font As Integer, ByVal hor_factor As Integer, _
            ByVal ver_factor As Integer, ByVal mode As Byte, ByVal data As String) As Integer
    Private Declare Function B_Prn_Text_Chinese Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal fonttype As Integer, ByVal id_name As String, ByVal data As String) As Integer
    Private Declare Function B_Prn_Text_TrueType Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, ByVal Fspin As Integer, _
            ByVal FWeight As Integer, ByVal FItalic As Integer, ByVal FUnline As Integer, _
            ByVal FStrikeOut As Integer, ByVal id_name As String, ByVal data As String) As Integer
    Private Declare Function B_Prn_Text_TrueType_W Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FHeight As Integer, ByVal FWidth As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As String) As Integer
    Private Declare Function B_Select_Option Lib "WINPPLB.DLL" (ByVal object_Renamed As Integer) As Integer
    Private Declare Function B_Select_Option2 Lib "WINPPLB.DLL" (ByVal object_Renamed As Integer, _
            ByVal p As Integer) As Integer
    Private Declare Function B_Select_Symbol Lib "WINPPLB.DLL" (ByVal num_bit As Integer, _
            ByVal symbol As Integer, ByVal country As Integer) As Integer
    Private Declare Function B_Select_Symbol2 Lib "WINPPLB.DLL" (ByVal num_bit As Integer, _
            ByVal symbol As String, ByVal country As Integer) As Integer
    Private Declare Function B_Set_Backfeed Lib "WINPPLB.DLL" (ByVal options As Byte) As Integer
    Private Declare Function B_Set_Backfeed_Offset Lib "WINPPLB.DLL" (ByVal offset As Integer) As Integer
    Private Declare Function B_Set_CutPeel_Offset Lib "WINPPLB.DLL" (ByVal offset As Integer) As Integer
    Private Declare Function B_Set_BMPSave Lib "WINPPLB.DLL" (ByVal nSave As Integer, _
            ByVal pstrBMPFName As String) As Integer
    Private Declare Function B_Set_Darkness Lib "WINPPLB.DLL" (ByVal darkness As Integer) As Integer
    Private Declare Function B_Set_DebugDialog Lib "WINPPLB.DLL" (ByVal nEnable As Integer) As Integer
    Private Declare Function B_Set_Direction Lib "WINPPLB.DLL" (ByVal direction As Byte) As Integer
    Private Declare Function B_Set_Form Lib "WINPPLB.DLL" (ByVal formfile As String) As Integer
    Private Declare Function B_Set_Labgap Lib "WINPPLB.DLL" (ByVal lablength As Integer, _
            ByVal gaplength As Integer) As Integer
    Private Declare Function B_Set_Labwidth Lib "WINPPLB.DLL" (ByVal labwidth As Integer) As Integer
    Private Declare Function B_Set_Originpoint Lib "WINPPLB.DLL" (ByVal hor As Integer, _
            ByVal ver As Integer) As Integer
    Private Declare Function B_Set_Prncomport Lib "WINPPLB.DLL" (ByVal baud As Integer, _
            ByVal parity As Byte, ByVal data As Integer, ByVal stopp As Integer) As Integer
    Private Declare Function B_Set_Prncomport_PC Lib "WINPPLB.DLL" (ByVal nBaudRate As Integer, _
            ByVal nByteSize As Integer, ByVal nParity As Integer, ByVal nStopBits As Integer, _
            ByVal nDsr As Integer, ByVal nCts As Integer, ByVal nXonXoff As Integer) As Integer
    Private Declare Function B_Set_Speed Lib "WINPPLB.DLL" (ByVal speed As Integer) As Integer
    Private Declare Function B_Set_ProcessDlg Lib "WINPPLB.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function B_Set_ErrorDlg Lib "WINPPLB.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function B_GetUSBBufferLen Lib "WINPPLB.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function B_EnumUSB Lib "WINPPLB.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function B_CreateUSBPort Lib "WINPPLB.DLL" (ByVal nPort As Integer) As Integer
    Private Declare Function B_ResetPrinter Lib "WINPPLB.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function B_GetPrinterResponse Lib "WINPPLB.DLL" (ByVal pbuf As Byte(), _
            ByVal nMax As Integer) As Integer
    Private Declare Function B_TFeedMode Lib "WINPPLB.DLL" (ByVal nMode As Integer) As Integer
    Private Declare Function B_TFeedTest Lib "WINPPLB.DLL" () As Integer
    Private Declare Function B_CreatePort Lib "WINPPLB.DLL" (ByVal nPortType As Integer, _
            ByVal nPort As Integer, ByVal filename As String) As Integer
    Private Declare Function B_Execute_Form Lib "WINPPLB.DLL" (ByVal form_out As String, _
            ByVal var As String) As Integer
    Private Declare Function B_Bar2d_QR Lib "WINPPLB.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal model As Integer, ByVal scl As Integer, ByVal err As Byte, ByVal dinput As Byte, _
            ByVal c As Integer, ByVal d As Integer, ByVal p As Integer, ByVal data As String) As Integer
    Private Declare Function B_GetNetPrinterBufferLen Lib "WINPPLB.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function B_EnumNetPrinter Lib "WINPPLB.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function B_CreateNetPort Lib "WINPPLB.DLL" (ByVal nPort As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function B_Prn_Text_TrueType_Uni Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, ByVal Fspin As Integer, _
            ByVal FWeight As Integer, ByVal FItalic As Integer, ByVal FUnline As Integer, _
            ByVal FStrikeOut As Integer, ByVal id_name As String, ByVal data As Byte(), _
            ByVal format As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function B_Prn_Text_TrueType_UniB Lib "WINPPLB.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, ByVal Fspin As Integer, _
            ByVal FWeight As Integer, ByVal FItalic As Integer, ByVal FUnline As Integer, _
            ByVal FStrikeOut As Integer, ByVal id_name As String, ByVal data As Byte(), _
            ByVal format As Integer) As Integer
    'pDeviceName and pDevicePath are buffer address, so can use "ByVal pDeviceName As String" and "ByVal pDevicePath As String". You can reference VB_6 example.
    Private Declare Function B_GetUSBDeviceInfo Lib "WINPPLB.DLL" (ByVal nPort As Integer, _
            ByVal pDeviceName As Byte(), ByRef pDeviceNameLen As Integer, ByVal pDevicePath As Byte(), _
            ByRef pDevicePathLen As Integer) As Integer
    Private Declare Function B_Set_EncryptionKey Lib "WINPPLB.DLL" (ByVal encryptionKey As String) As Integer
    Private Declare Function B_Check_EncryptionKey Lib "WINPPLB.DLL" (ByVal decodeKey As String, _
            ByVal encryptionKey As String, ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function B_Set_CommTimeout Lib "WINPPLB.DLL" (ByVal ReadTotalTimeoutConstant As Integer, _
            ByVal WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function B_Get_CommTimeout Lib "WINPPLB.DLL" (ByRef ReadTotalTimeoutConstant As Integer, _
            ByRef WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function B_Set_LabelForSmartPrint Lib "WINPPLB.DLL" (ByVal lablength As Integer, _
            ByVal gaplength As Integer) As Integer


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Test code start
        ' open port.
        Dim nLen As Integer
        Dim ret As Integer
        Dim sw As Integer
        Dim pbuf(128) As Byte
        Dim nVersion, nMainVersion, nSubVersion As Integer
        Dim strmsg As String
        Dim encAscII = System.Text.Encoding.ASCII
        Dim encUnicode = System.Text.Encoding.Unicode

        ' dll version.
        nVersion = B_Get_DLL_VersionA(0)
        nMainVersion = nVersion / 100
        nSubVersion = nVersion Mod 100

        ' search port.
        nLen = B_GetUSBBufferLen() + 1
        strmsg = "DLL Ver: " + Str(nMainVersion) + "." + Str(nSubVersion) + vbCrLf
        If nLen > 1 Then
            Dim buf1() As Byte
            Dim buf2() As Byte
            Dim len1 As Integer = 128
            Dim len2 As Integer = 128
            ReDim buf1(len1) ' buf1= New Byte(len1) {}
            ReDim buf2(len2) ' buf2= New Byte(len2) {}
            Call B_EnumUSB(pbuf)
            Call B_GetUSBDeviceInfo(1, buf1, len1, buf2, len2)
            sw = 1
            If sw Then
                ret = B_CreatePrn(12, encAscII.GetString(buf2, 0, len2)) ' open usb.
            Else
                ret = B_CreateUSBPort(1) ' must call B_GetUSBBufferLen() function fisrt.
            End If
            If 0 < ret Then
                strmsg += "Open USB fail!"
            Else
                strmsg += "Open USB:" + vbCrLf + "Device name: "
                strmsg += encAscII.GetString(buf1, 0, len1)
                strmsg += vbCrLf + "Device path: "
                strmsg += encAscII.GetString(buf2, 0, len2)
                'sw = 2
                If 2 = sw Then
                    'Immediate Error Report.
                    B_WriteData(1, encAscII.GetBytes("^ee\r\n"), 5)   '^ee
                    ret = B_ReadData(pbuf, 4, 1000)
                End If
            End If
        Else
            System.IO.Directory.CreateDirectory(szSavePath)
            ret = B_CreatePrn(0, szSaveFile) ' open file.
            strmsg += "Open "
            strmsg += szSaveFile
            If 0 < ret Then
                strmsg += " file fail!"
            Else
                strmsg += " file succeed!"
            End If
        End If
        MessageBox.Show(strmsg)
        If 0 < ret Then
            Exit Sub
        End If

        ' sample setting.
        Call B_Set_DebugDialog(1)
        Call B_Set_Originpoint(0, 0)
        Call B_Select_Option(2)
        Call B_Set_Darkness(8)
        Call B_Del_Pcx("*") ' delete all picture.
        Call B_WriteData(0, encAscII.GetBytes(sznop2), sznop2.Length)
        Call B_WriteData(1, encAscII.GetBytes(sznop1), sznop1.Length)
        ' When using standard label, and the printer is Intelli Print mode or Smart Print mode,
        ' When calling this function and giving the correct label information,
        ' the immediate print function will be enabled according to the label length setting.
        Call B_Set_LabelForSmartPrint(254 * 3, 30) ' label information: length= 3 * 25.4 mm, gap= 3 mm.

        'draw box.
        Call B_Draw_Box(20, 20, 4, 760, 560)
        Call B_Draw_Line(Asc("O"), 400, 20, 4, 540)

        'print text, true type text.
        Call B_Prn_Text(30, 40, 0, 2, 1, 1, Asc("N"), "PPLB Lib Example")
        Call B_Prn_Text_TrueType(30, 100, 30, "Arial", 1, 400, 0, 0, 0, "AA", "TrueType Font") 'save in printer.
        Call B_Prn_Text_TrueType_W(30, 160, 20, 20, "Times New Roman", 1, 400, 0, 0, 0, "AB", "TT_W: �h�r������")
        Call B_Prn_Text_TrueType_Uni(30, 220, 30, "Times New Roman", 1, 400, 0, 0, 0, "AC", encUnicode.GetBytes("TT_Uni: �h�r������"), 1) 'UTF-16
        pbuf(0) = 255 'UTF-16.
        pbuf(1) = 254
        encUnicode.GetBytes("TT_UniB: �h�r������", 0, 14, pbuf, 2) 'copy mutil byte.
        pbuf(30) = 0 'null.
        pbuf(31) = 0
        Call B_Prn_Text_TrueType_UniB(30, 280, 30, "Times New Roman", 1, 400, 0, 0, 0, "AD", pbuf, 0) 'Byte Order Mark.

        'barcode.
        Call B_Prn_Barcode(420, 100, 0, "3", 2, 3, 40, Asc("B"), "1234<+1>") 'have a counter.
        Call B_Bar2d_QR(420, 200, 1, 3, Asc("M"), Asc("A"), 0, 0, 0, "QR CODE")

        'picture.
        Call B_Get_Graphic_ColorBMP(420, 280, "bb.bmp") ' Color bmp file.
        Call B_Get_Graphic_ColorBMPEx(420, 320, 200, 150, 2, "bb1", "bb.bmp") ' 180 angle.
        Dim himage As Integer
        himage = LoadImage(0, "bb.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE)
        Call B_Get_Graphic_ColorBMP_HBitmap(630, 280, 250, 80, 1, "bb2", himage) ' 90 angle.
        If himage Then
            Call DeleteObject(himage)
        End If

        ' output.
        Call B_Print_Out(2) ' copy 2.

        ' close port.
        Call B_ClosePrn()

    End Sub
End Class
