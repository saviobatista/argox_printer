Notice:
1.\Win32  : The sample code select "32-bit of CPU" to compile, so please use 32-bit library.
  \AnyCPU : The sample code select "AnyCPU" to compile, so please use the same bits library as your OS.
2.If you don't know where to place WINPPLA.DLL and WINPORT.DLL, please to put them together with application execution file.