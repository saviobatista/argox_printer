
Public Class Form1
    Const IMAGE_BITMAP = 0
    Const LR_LOADFROMFILE = &H10
    Private Declare Function LoadImage Lib "user32" Alias "LoadImageA" (ByVal hInst As Integer, _
            ByVal lpsz As String, ByVal un1 As Integer, ByVal n1 As Integer, ByVal n2 As Integer, _
            ByVal un2 As Integer) As Integer
    Private Declare Function DeleteObject Lib "Gdi32" (ByVal ho As Integer) As Integer
    Const szSavePath As String = "C:\Argox"
    Const szSaveFile As String = "C:\Argox\PPLA_Example.Prn"
    Const sznop1 As String = "nop_front" + vbCrLf
    Const sznop2 As String = "nop_middle" + vbCrLf
    Private Declare Function A_Bar2d_Maxi Lib "WINPPLA.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal primary As Integer, ByVal secondary As Integer, ByVal country As Integer, _
            ByVal service As Integer, ByVal mode As Byte, ByVal numeric As Integer, _
            ByVal data As String) As Integer
    Private Declare Function A_Bar2d_Maxi_Ori Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal ori As Integer, ByVal primary As Integer, _
            ByVal secondary As Integer, ByVal country As Integer, ByVal service As Integer, _
            ByVal mode As Byte, ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Bar2d_PDF417 Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal narrow As Integer, ByVal width As Integer, _
            ByVal normal As Byte, ByVal security As Integer, ByVal aspect As Integer, _
            ByVal row As Integer, ByVal column As Integer, ByVal mode As Byte, _
            ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Bar2d_PDF417_Ori Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal ori As Integer, ByVal narrow As Integer, _
            ByVal width As Integer, ByVal normal As Byte, ByVal security As Integer, _
            ByVal aspect As Integer, ByVal row As Integer, ByVal column As Integer, _
            ByVal mode As Byte, ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Bar2d_DataMatrix Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal rotation As Integer, ByVal hor_mul As Integer, _
            ByVal ver_mul As Integer, ByVal ECC As Integer, ByVal data_format As Integer, _
            ByVal num_rows As Integer, ByVal num_col As Integer, ByVal mode As Byte, _
            ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Sub A_Clear_Memory Lib "WINPPLA.DLL" ()
    Private Declare Sub A_ClosePrn Lib "WINPPLA.DLL" ()
    Private Declare Function A_CreatePrn Lib "WINPPLA.DLL" (ByVal selection As Integer, _
            ByVal filename As String) As Integer
    Private Declare Function A_Del_Graphic Lib "WINPPLA.DLL" (ByVal mem_mode As Integer, _
            ByVal graphic As String) As Integer
    Private Declare Function A_Draw_Box Lib "WINPPLA.DLL" (ByVal mode As Byte, ByVal x As Integer, _
            ByVal y As Integer, ByVal width As Integer, ByVal height As Integer, _
            ByVal top As Integer, ByVal side As Integer) As Integer
    Private Declare Function A_Draw_Line Lib "WINPPLA.DLL" (ByVal mode As Byte, ByVal x As Integer, _
            ByVal y As Integer, ByVal width As Integer, ByVal height As Integer) As Integer
    Private Declare Sub A_Feed_Label Lib "WINPPLA.DLL" ()
    Private Declare Function A_Get_DLL_Version Lib "WINPPLA.DLL" (ByVal nShowMessage As Integer) As String
    Private Declare Function A_Get_DLL_VersionA Lib "WINPPLA.DLL" (ByVal nShowMessage As Integer) As Integer
    Private Declare Function A_Get_Graphic Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal mem_mode As Integer, ByVal format As Byte, _
            ByVal filename As String) As Integer
    Private Declare Function A_Get_Graphic_ColorBMP Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal mem_mode As Integer, ByVal format As Byte, _
            ByVal filename As String) As Integer
    Private Declare Function A_Get_Graphic_ColorBMPEx Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal mem_mode As Integer, ByVal format As Byte, _
            ByVal id_name As String, ByVal filename As String) As Integer
    Private Declare Function A_Get_Graphic_ColorBMP_HBitmap Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal mem_mode As Integer, ByVal format As Byte, _
            ByVal id_name As String, ByVal hbm As Integer) As Integer
    Private Declare Function A_Initial_Setting Lib "WINPPLA.DLL" (ByVal ttype As Integer, _
            ByVal Source As String) As Integer
    Private Declare Function A_WriteData Lib "WINPPLA.DLL" (ByVal IsImmediate As Integer, _
            ByVal pbuf As Byte(), ByVal length As ULong) As Integer
    Private Declare Function A_ReadData Lib "WINPPLA.DLL" (ByVal pbuf As Byte(), ByVal length As ULong, _
            ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function A_Load_Graphic Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal Graphic_name As String) As Integer
    Private Declare Function A_Open_ChineseFont Lib "WINPPLA.DLL" (ByVal path As String) As Integer
    Private Declare Function A_Print_Form Lib "WINPPLA.DLL" (ByVal width As Integer, _
            ByVal height As Integer, ByVal copies As Integer, ByVal amount As Integer, _
            ByVal form_name As String) As Integer
    Private Declare Function A_Print_Out Lib "WINPPLA.DLL" (ByVal width As Integer, _
            ByVal height As Integer, ByVal copies As Integer, ByVal amount As Integer) As Integer
    Private Declare Function A_Prn_Barcode Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal ori As Integer, ByVal typee As Byte, ByVal narrow As Integer, _
            ByVal width As Integer, ByVal height As Integer, ByVal mode As Byte, _
            ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Prn_Text Lib "WINPPLA.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal font As Integer, ByVal typee As Integer, _
            ByVal hor_factor As Integer, ByVal ver_factor As Integer, ByVal mode As Byte, _
            ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Prn_Text_Chinese Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal fonttype As Integer, ByVal id_name As String, _
            ByVal data As String, ByVal mem_mode As Integer) As Integer
    Private Declare Function A_Prn_Text_TrueType Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As String, ByVal mem_mode As Integer) As Integer
    Private Declare Function A_Prn_Text_TrueType_W Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FHeight As Integer, ByVal FWidth As Integer, _
            ByVal FType As String, ByVal Fspin As Integer, ByVal FWeight As Integer, _
            ByVal FItalic As Integer, ByVal FUnline As Integer, ByVal FStrikeOut As Integer, _
            ByVal id_name As String, ByVal data As String, ByVal mem_mode As Integer) As Integer
    Private Declare Function A_Set_Backfeed Lib "WINPPLA.DLL" (ByVal back As Integer) As Integer
    Private Declare Function A_Set_BMPSave Lib "WINPPLA.DLL" (ByVal nSave As Integer, _
            ByVal pstrBMPFName As String) As Integer
    Private Declare Function A_Set_Cutting Lib "WINPPLA.DLL" (ByVal cutting As Integer) As Integer
    Private Declare Function A_Set_Darkness Lib "WINPPLA.DLL" (ByVal darkness As Integer) As Integer
    Private Declare Function A_Set_DebugDialog Lib "WINPPLA.DLL" (ByVal nEnable As Integer) As Integer
    Private Declare Function A_Set_Feed Lib "WINPPLA.DLL" (ByVal rate As Byte) As Integer
    Private Declare Function A_Set_Form Lib "WINPPLA.DLL" (ByVal formfile As String, _
            ByVal form_name As String, ByVal mem_mode As Integer) As Integer
    Private Declare Function A_Set_Margin Lib "WINPPLA.DLL" (ByVal position As Integer, _
            ByVal margin As Integer) As Integer
    Private Declare Function A_Set_Prncomport Lib "WINPPLA.DLL" (ByVal baud As Integer, _
            ByVal parity As Integer, ByVal data As Integer, ByVal sstop As Integer) As Integer
    Private Declare Function A_Set_Prncomport_PC Lib "WINPPLA.DLL" (ByVal nBaudRate As Integer, _
            ByVal nByteSize As Integer, ByVal nParity As Integer, ByVal nStopBits As Integer, _
            ByVal nDsr As Integer, ByVal nCts As Integer, ByVal nXonXoff As Integer) As Integer
    Private Declare Function A_Set_Sensor_Mode Lib "WINPPLA.DLL" (ByVal ttype As Byte, _
            ByVal continuous As Integer) As Integer
    Private Declare Function A_Set_Speed Lib "WINPPLA.DLL" (ByVal speed As Byte) As Integer
    Private Declare Function A_Set_Syssetting Lib "WINPPLA.DLL" (ByVal transfer As Integer, _
            ByVal cut_peel As Integer, ByVal length As Integer, ByVal zero As Integer, _
            ByVal pause As Integer) As Integer
    Private Declare Function A_Set_Unit Lib "WINPPLA.DLL" (ByVal unit As Byte) As Integer
    Private Declare Function A_Set_Gap Lib "WINPPLA.DLL" (ByVal gap As Integer) As Integer
    Private Declare Function A_Set_Logic Lib "WINPPLA.DLL" (ByVal Logic As Integer) As Integer
    Private Declare Function A_Set_ProcessDlg Lib "WINPPLA.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function A_Set_ErrorDlg Lib "WINPPLA.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function A_Set_LabelVer Lib "WINPPLA.DLL" (ByVal centiInch As Integer) As Integer
    Private Declare Function A_GetUSBBufferLen Lib "WINPPLA.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function A_EnumUSB Lib "WINPPLA.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function A_CreateUSBPort Lib "WINPPLA.DLL" (ByVal nPort As Integer) As Integer
    Private Declare Function A_CreatePort Lib "WINPPLA.DLL" (ByVal nPortType As Integer, _
            ByVal nPort As Integer, ByVal filename As String) As Integer
    Private Declare Sub A_Clear_MemoryEx Lib "WINPPLA.DLL" (ByVal nMode As Integer)
    Private Declare Sub A_Set_Mirror Lib "WINPPLA.DLL" ()
    Private Declare Function A_Bar2d_RSS Lib "WINPPLA.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal ratio As Integer, ByVal height As Integer, _
            ByVal rtype As Byte, ByVal mult As Integer, ByVal seg As Integer, ByVal data1 As String, _
            ByVal data2 As String) As Integer
    Private Declare Function A_Bar2d_QR_M Lib "WINPPLA.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal mult As Byte, ByVal value As Integer, _
            ByVal model As Integer, ByVal err As Byte, ByVal mask As Integer, ByVal dinput As Byte, _
            ByVal mode As Byte, ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_Bar2d_QR_A Lib "WINPPLA.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal mult As Byte, ByVal value As Integer, ByVal mode As Byte, _
            ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function A_GetNetPrinterBufferLen Lib "WINPPLA.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function A_EnumNetPrinter Lib "WINPPLA.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function A_CreateNetPort Lib "WINPPLA.DLL" (ByVal nPort As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function A_Prn_Text_TrueType_Uni Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As Byte(), ByVal format As Integer, ByVal mem_mode As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function A_Prn_Text_TrueType_UniB Lib "WINPPLA.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As Byte(), ByVal format As Integer, ByVal mem_mode As Integer) As Integer
    'pDeviceName and pDevicePath are buffer address, so can use "ByVal pDeviceName As String" and "ByVal pDevicePath As String". You can reference VB_6 example.
    Private Declare Function A_GetUSBDeviceInfo Lib "WINPPLA.DLL" (ByVal nPort As Integer, _
            ByVal pDeviceName As Byte(), ByRef pDeviceNameLen As Integer, _
            ByVal pDevicePath As Byte(), ByRef pDevicePathLen As Integer) As Integer
    Private Declare Function A_Set_EncryptionKey Lib "WINPPLA.DLL" (ByVal encryptionKey As String) As Integer
    Private Declare Function A_Check_EncryptionKey Lib "WINPPLA.DLL" (ByVal decodeKey As String, _
            ByVal encryptionKey As String, ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function A_Set_CommTimeout Lib "WINPPLA.DLL" (ByVal ReadTotalTimeoutConstant As Integer, _
            ByVal WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function A_Get_CommTimeout Lib "WINPPLA.DLL" (ByRef ReadTotalTimeoutConstant As Integer, _
            ByRef WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function A_Set_LabelForSmartPrint Lib "WINPPLA.DLL" (ByVal lablength As Integer, _
            ByVal gaplength As Integer) As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Test code start
        ' open port.
        Dim nLen As Integer
        Dim ret As Integer
        Dim sw As Integer
        Dim pbuf(128) As Byte
        Dim nVersion, nMainVersion, nSubVersion As Integer
        Dim strmsg As String
        Dim encAscII = System.Text.Encoding.ASCII
        Dim encUnicode = System.Text.Encoding.Unicode

        ' dll version.
        nVersion = A_Get_DLL_VersionA(0)
        nMainVersion = nVersion / 100
        nSubVersion = nVersion Mod 100

        ' search port.
        nLen = A_GetUSBBufferLen() + 1
        strmsg = "DLL Ver: " + Str(nMainVersion) + "." + Str(nSubVersion) + vbCrLf
        If nLen > 1 Then
            Dim buf1() As Byte
            Dim buf2() As Byte
            Dim len1 As Integer = 128
            Dim len2 As Integer = 128
            ReDim buf1(len1) ' buf1= New Byte(len1) {}
            ReDim buf2(len2) ' buf2= New Byte(len2) {}
            Call A_EnumUSB(pbuf)
            Call A_GetUSBDeviceInfo(1, buf1, len1, buf2, len2)
            sw = 1
            If sw Then
                ret = A_CreatePrn(12, encAscII.GetString(buf2, 0, len2)) ' open usb.
            Else
                ret = A_CreateUSBPort(1) ' must call A_GetUSBBufferLen() function fisrt.
            End If
            If 0 < ret Then
                strmsg += "Open USB fail!"
            Else
                strmsg += "Open USB:" + vbCrLf + "Device name: "
                strmsg += encAscII.GetString(buf1, 0, len1)
                strmsg += vbCrLf + "Device path: "
                strmsg += encAscII.GetString(buf2, 0, len2)
                'sw = 2
                If 2 = sw Then
                    'get printer status.
                    pbuf(0) = &H1
                    pbuf(1) = &H46
                    pbuf(2) = &HD
                    pbuf(3) = &HA
                    A_WriteData(1, pbuf, 4)   '<SOH>F
                    ret = A_ReadData(pbuf, 2, 1000)
                End If
            End If
        Else
            System.IO.Directory.CreateDirectory(szSavePath)
            ret = A_CreatePrn(0, szSaveFile) ' open file.
            strmsg += "Open "
            strmsg += szSaveFile
            If 0 < ret Then
                strmsg += " file fail!"
            Else
                strmsg += " file succeed!"
            End If
        End If
        MessageBox.Show(strmsg)
        If 0 < ret Then
            Exit Sub
        End If

        ' sample setting.
        Call A_Set_DebugDialog(1)
        Call A_Set_Unit(Asc("n"))
        Call A_Set_Syssetting(1, 0, 0, 0, 0)
        Call A_Set_Darkness(8)
        Call A_Del_Graphic(1, "*") ' delete all picture.
        Call A_Clear_Memory() ' clear memory.
        Call A_WriteData(0, encAscII.GetBytes(sznop2), sznop2.Length)
        Call A_WriteData(1, encAscII.GetBytes(sznop1), sznop1.Length)
        ' When using standard label, and the printer is Intelli Print mode or Smart Print mode,
        ' When calling this function and giving the correct label information,
        ' the immediate print function will be enabled according to the label length setting.
        Call A_Set_LabelForSmartPrint(254 * 3, 30) ' label information: length= 3 * 25.4 mm, gap= 3 mm.

        'draw box.
        Call A_Draw_Box(Asc("A"), 10, 10, 380, 280, 4, 4)
        Call A_Draw_Line(Asc("A"), 200, 10, 4, 280)

        'print text, true type text.
        Call A_Prn_Text(20, 30, 1, 2, 0, 1, 1, Asc("N"), 2, "PPLA Lib Example")
        Call A_Prn_Text_TrueType(20, 60, 30, "Arial", 1, 400, 0, 0, 0, "AA", "TrueType Font", 1) 'save in ram.
        Call A_Prn_Text_TrueType_W(20, 90, 20, 20, "Times New Roman", 1, 400, 0, 0, 0, "AB", "TT_W: �h�r������", 1)
        Call A_Prn_Text_TrueType_Uni(20, 120, 30, "Times New Roman", 1, 400, 0, 0, 0, "AC", encUnicode.GetBytes("TT_Uni: �h�r������"), 1, 1) 'UTF-16
        pbuf(0) = 255 'UTF-16.
        pbuf(1) = 254
        encUnicode.GetBytes("TT_UniB: �h�r������", 0, 14, pbuf, 2) 'copy mutil byte.
        pbuf(30) = 0 'null.
        pbuf(31) = 0
        Call A_Prn_Text_TrueType_UniB(20, 150, 30, "Times New Roman", 1, 400, 0, 0, 0, "AD", pbuf, 0, 1) 'Byte Order Mark.

        'barcode.

        Call A_Prn_Barcode(220, 60, 1, Asc("A"), 0, 0, 20, Asc("B"), 1, "1234")
        Call A_Bar2d_QR_A(220, 100, 1, Asc("3"), 10, Asc("N"), 0, "QR CODE")

        'picture.
        Call A_Get_Graphic_ColorBMP(220, 150, 1, Asc("B"), "bb.bmp") ' Color bmp file to ram.
        Call A_Get_Graphic_ColorBMPEx(220, 170, 200, 150, 2, 1, Asc("B"), "bb1", "bb.bmp") ' 180 angle.
        Dim himage As Integer
        himage = LoadImage(0, "bb.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE)
        Call A_Get_Graphic_ColorBMP_HBitmap(300, 150, 250, 80, 1, 1, Asc("B"), "bb2", himage) ' 90 angle.
        If himage Then
            Call DeleteObject(himage)
        End If

        ' output.
        Call A_Print_Out(1, 1, 2, 1) ' copy 2.

        ' close port.
        Call A_ClosePrn()
    End Sub
End Class
