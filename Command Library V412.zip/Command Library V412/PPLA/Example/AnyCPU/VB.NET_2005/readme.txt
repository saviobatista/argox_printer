VB.NET_2005_32-bit.sln : 
	The project select "x86"(This is 32-bit) to compile, 
	and application file is put in ..\bin\x86\Release folder.
	Note : Please run the application with 32-bit library.

VB.NET_2005_AnyCPU.sln :
	The project select "AnyCPU" to compile, 
	and application file is put in ..\bin\Release folder.
	Note : Please run the application with 32-bit or 64-bit library that the same your OS.