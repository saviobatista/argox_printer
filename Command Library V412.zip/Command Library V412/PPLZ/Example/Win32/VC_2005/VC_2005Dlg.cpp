// VC_2005Dlg.cpp : ��@��
//

#include "stdafx.h"
#include "VC_2005.h"
#include "VC_2005Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

const char szSavePath[] = "C:\\Argox";
const char szSaveFile[] = "C:\\Argox\\PPLZ_Example.Prn";
const char sznop1[]     = "nop_front\r\n";
const char sznop2[]     = "nop_middle\r\n";
// PPLZDLL Function Declaration start
HINSTANCE hPPLZ;
typedef int   (_stdcall *pfnZ_Bar2d_Maxi)(int x, int y, int nMode, int nSymbol, int nTotal,
						 int nClass, int nCountry, char cZipCode1[6], char cZipCode2[4],
						 LPCTSTR data, int increase);
typedef int   (_stdcall *pfnZ_Bar2d_PDF417)(int x, int y, int o, int h, int s, int c, int r, int t,
						 int narrow, LPCTSTR data, int increase);
typedef int   (_stdcall *pfnZ_Bar2d_DataMatrix)(int x, int y, int o, int h, int c, int r,
						 LPCTSTR data, int increase);
typedef void  (_stdcall *pfnZ_ClosePrn)(void);
typedef int   (_stdcall *pfnZ_CreatePrn)(int selection, LPCTSTR filename);
typedef int   (_stdcall *pfnZ_Set_FlashMemory)(int Status);
typedef void  (_stdcall *pfnZ_Set_Format_New)(LPCTSTR FormatName);
typedef int   (_stdcall *pfnZ_Del_Format)(int memory, char formatname[11]);
typedef int   (_stdcall *pfnZ_Del_Graphic)(int memory, char graphicname[11]);
typedef int   (_stdcall *pfnZ_Draw_Box)(int x, int y, int width, int height, int thickness);
typedef int   (_stdcall *pfnZ_Draw_Line)(int x, int y, int width, int height);
typedef char* (_stdcall *pfnZ_Get_DLL_Version)(int nShowMessage);
typedef int   (_stdcall *pfnZ_Get_DLL_VersionA)(int nShowMessage);
typedef int   (_stdcall *pfnZ_Get_Graphic_ColorBMP)(int x, int y, int mem_mode, LPCTSTR filename);
typedef int   (_stdcall *pfnZ_Get_Graphic_ColorBMPEx)(int x, int y, int nWidth, int nHeight,
						 int rotate, int mem_mode, LPCTSTR id_name, LPCTSTR filename);
typedef int   (_stdcall *pfnZ_Get_Graphic_ColorBMP_HBitmap)(int x, int y, int nWidth, int nHeight,
						 int rotate, int mem_mode, LPCTSTR id_name, HBITMAP hbm);
typedef int   (_stdcall *pfnZ_Initial_Setting)(int Type, LPCTSTR Source);
typedef int   (_stdcall *pfnZ_WriteData)(int IsImmediate, LPCTSTR pbuf, DWORD length);
typedef int   (_stdcall *pfnZ_ReadData)(LPTSTR pbuf, DWORD length, DWORD dwTimeoutms);
typedef int   (_stdcall *pfnZ_Load_Graphic)(int x, int y, int memory, char graphic_name[10],
						 int horizontal, int vertical);
typedef int   (_stdcall *pfnZ_Open_ChineseFont)(char* path);
typedef int   (_stdcall *pfnZ_Print_Form)(int copies, int labset, int mem_mode, char form_out[11]);
typedef int   (_stdcall *pfnZ_Print_Out)(int sets, int copies);
typedef int   (_stdcall *pfnZ_Prn_Barcode)(int x, int y, int ori, int narrow, int width, int height,
						 char type, int increase, LPCTSTR data, char human1, char human2,
						 char human3, char human4, char human5);
typedef int   (_stdcall *pfnZ_Prn_Text)(int x, int y, int ori, char font, int height, int width,
						 int numeric, LPCTSTR data);
typedef int   (_stdcall *pfnZ_Prn_Text_Chinese)(int x, int y, int fonttype, LPCTSTR id_name,
						 LPCTSTR data, int mem_mode);
typedef int   (_stdcall *pfnZ_Prn_Text_TrueType)(int x, int y, int FSize, LPCTSTR FType, int Fspin,
						 int FWeight, int FItalic, int FUnline, int FStrikeOut, LPCTSTR id_name,
						 LPCTSTR data, int mem_mode);
typedef int   (_stdcall *pfnZ_Prn_Text_TrueType_W)(int x, int y, int FHeight, int FWidth,
						 LPCTSTR FType, int Fspin, int FWeight, int FItalic, int FUnline,
						 int FStrikeOut, LPCTSTR id_name, LPCTSTR data, int mem_mode);
typedef void  (_stdcall *pfnZ_Clear_Memory)(void);
typedef void  (_stdcall *pfnZ_Clear_MemoryEx)(int nMode);
typedef int   (_stdcall *pfnZ_Set_Backfeed)(int nDistance);
typedef int   (_stdcall *pfnZ_Set_Darkness)(int darkness);
typedef int   (_stdcall *pfnZ_Set_DebugDialog)(int nEnable);
typedef int   (_stdcall *pfnZ_Set_Label)(int Length);
typedef int   (_stdcall *pfnZ_Set_Mode)(char mode);
typedef int   (_stdcall *pfnZ_Set_Origin)(int y);
typedef int   (_stdcall *pfnZ_Set_Paper)(char mode);
typedef int   (_stdcall *pfnZ_Set_Prncomport)(int baud, int parity, int data, int stop);
typedef int   (_stdcall *pfnZ_Set_Prncomport_PC)(int nBaudRate, int nByteSize, int nParity,
						 int nStopBits, int nDsr, int nCts, int nXonXoff);
typedef void  (_stdcall *pfnZ_Set_Reset)(void);
typedef int   (_stdcall *pfnZ_Set_Speed)(int print);
typedef int   (_stdcall *pfnZ_Set_TPH)(char mode);
typedef int   (_stdcall *pfnZ_Set_Unit)(char Unit);
typedef int   (_stdcall *pfnZ_Set_Gap)(int nPatern, int nGap);
typedef int   (_stdcall *pfnZ_Set_ProcessDlg)(int nShow);
typedef int   (_stdcall *pfnZ_Set_ErrorDlg)(int nShow);
typedef int   (_stdcall *pfnZ_Bar2d_QRCode)(int x, int y, int nModel, int nMagni, int nErr_Cor,
						 int nInput, LPCTSTR data, int increase);
typedef int   (_stdcall *pfnZ_Set_PrintWidth)(int nDotwidth);
typedef int   (_stdcall *pfnZ_Print_OutQuality)(int nTotal, int sets, int copies, int nPause);
typedef int   (_stdcall *pfnZ_GetUSBBufferLen)(void);
typedef int   (_stdcall *pfnZ_EnumUSB)(char *buf);
typedef int   (_stdcall *pfnZ_CreateUSBPort)(int nPort);
typedef int   (_stdcall *pfnZ_CreatePort)(int nPortType, int nPort, LPCTSTR filename);
typedef int   (_stdcall *pfnZ_Set_Mirror)(char direction);
typedef int   (_stdcall *pfnZ_Bar2d_RSS)(int x, int y, char ori, int rtype, int mag, int height,
						 int seg, LPCTSTR data1, LPCTSTR data2);
typedef int   (_stdcall *pfnZ_GetNetPrinterBufferLen)(void);
typedef int   (_stdcall *pfnZ_EnumNetPrinter)(char *buf);
typedef int   (_stdcall *pfnZ_CreateNetPort)(int nPort);
typedef int   (_stdcall *pfnZ_Prn_Text_TrueType_Uni)(int x, int y, int FSize, LPCTSTR FType,
						 int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut,
						 LPCTSTR id_name, LPCWSTR data, int format, int mem_mode);
typedef int   (_stdcall *pfnZ_Prn_Text_TrueType_UniB)(int x, int y, int FSize, LPCTSTR FType,
						 int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut,
						 LPCTSTR id_name, LPCTSTR data, int format, int mem_mode);
typedef int   (_stdcall *pfnZ_GetUSBDeviceInfo)(int nPort, char *pDeviceName, int *pDeviceNameLen, 
						 char *pDevicePath, int *pDevicePathLen);
typedef int   (_stdcall *pfnZ_Set_EncryptionKey)(char encryptionKey[16]);
typedef int   (_stdcall *pfnZ_Check_EncryptionKey)(char decodeKey[8], char encryptionKey[16], 
						 DWORD dwTimeoutms);
typedef void  (_stdcall *pfnZ_Set_CommTimeout)(int ReadTotalTimeoutConstant, int WriteTotalTimeoutConstant);
typedef void  (_stdcall *pfnZ_Get_CommTimeout)(int *ReadTotalTimeoutConstant, int *WriteTotalTimeoutConstant);
typedef void  (_stdcall *pfnZ_Set_LabelForSmartPrint)(int lablength, int gaplength);

pfnZ_Bar2d_Maxi				Z_Bar2d_Maxi			= NULL;
pfnZ_Bar2d_PDF417			Z_Bar2d_PDF417			= NULL;
pfnZ_Bar2d_DataMatrix		Z_Bar2d_DataMatrix		= NULL;
pfnZ_ClosePrn				Z_ClosePrn				= NULL;
pfnZ_CreatePrn				Z_CreatePrn				= NULL;
pfnZ_Set_FlashMemory		Z_Set_FlashMemory		= NULL;
pfnZ_Set_Format_New			Z_Set_Format_New		= NULL;
pfnZ_Del_Format				Z_Del_Format			= NULL;
pfnZ_Del_Graphic			Z_Del_Graphic			= NULL;
pfnZ_Draw_Box				Z_Draw_Box				= NULL;
pfnZ_Draw_Line				Z_Draw_Line				= NULL;
pfnZ_Get_DLL_Version		Z_Get_DLL_Version		= NULL;
pfnZ_Get_DLL_VersionA		Z_Get_DLL_VersionA		= NULL;
pfnZ_Get_Graphic_ColorBMP	Z_Get_Graphic_ColorBMP	= NULL;
pfnZ_Get_Graphic_ColorBMPEx	Z_Get_Graphic_ColorBMPEx	= NULL;
pfnZ_Get_Graphic_ColorBMP_HBitmap	Z_Get_Graphic_ColorBMP_HBitmap	= NULL;
pfnZ_Initial_Setting		Z_Initial_Setting		= NULL;
pfnZ_WriteData				Z_WriteData				= NULL;
pfnZ_ReadData				Z_ReadData				= NULL;
pfnZ_Load_Graphic			Z_Load_Graphic			= NULL;
pfnZ_Open_ChineseFont		Z_Open_ChineseFont		= NULL;
pfnZ_Print_Form				Z_Print_Form			= NULL;
pfnZ_Print_Out				Z_Print_Out				= NULL;
pfnZ_Prn_Barcode			Z_Prn_Barcode			= NULL;
pfnZ_Prn_Text				Z_Prn_Text				= NULL;
pfnZ_Prn_Text_Chinese		Z_Prn_Text_Chinese		= NULL;
pfnZ_Prn_Text_TrueType		Z_Prn_Text_TrueType		= NULL;
pfnZ_Prn_Text_TrueType_W	Z_Prn_Text_TrueType_W	= NULL;
pfnZ_Clear_Memory			Z_Clear_Memory			= NULL;
pfnZ_Clear_MemoryEx			Z_Clear_MemoryEx		= NULL;
pfnZ_Set_Backfeed			Z_Set_Backfeed			= NULL;
pfnZ_Set_Darkness			Z_Set_Darkness			= NULL;
pfnZ_Set_DebugDialog		Z_Set_DebugDialog		= NULL;
pfnZ_Set_Label				Z_Set_Label				= NULL;
pfnZ_Set_Mode				Z_Set_Mode				= NULL;
pfnZ_Set_Origin				Z_Set_Origin			= NULL;
pfnZ_Set_Paper				Z_Set_Paper				= NULL;
pfnZ_Set_Prncomport			Z_Set_Prncomport		= NULL;
pfnZ_Set_Prncomport_PC		Z_Set_Prncomport_PC		= NULL;
pfnZ_Set_Reset				Z_Set_Reset				= NULL;
pfnZ_Set_Speed				Z_Set_Speed				= NULL;
pfnZ_Set_TPH				Z_Set_TPH				= NULL;
pfnZ_Set_Unit				Z_Set_Unit				= NULL;
pfnZ_Set_Gap				Z_Set_Gap				= NULL;
pfnZ_Set_ProcessDlg			Z_Set_ProcessDlg		= NULL;
pfnZ_Set_ErrorDlg			Z_Set_ErrorDlg			= NULL;
pfnZ_Bar2d_QRCode			Z_Bar2d_QRCode			= NULL;
pfnZ_Set_PrintWidth			Z_Set_PrintWidth		= NULL;
pfnZ_Print_OutQuality		Z_Print_OutQuality		= NULL;
pfnZ_GetUSBBufferLen		Z_GetUSBBufferLen		= NULL;
pfnZ_EnumUSB				Z_EnumUSB				= NULL;
pfnZ_CreateUSBPort			Z_CreateUSBPort			= NULL;
pfnZ_CreatePort				Z_CreatePort			= NULL;
pfnZ_Set_Mirror				Z_Set_Mirror			= NULL;
pfnZ_Bar2d_RSS				Z_Bar2d_RSS				= NULL;
pfnZ_GetNetPrinterBufferLen	Z_GetNetPrinterBufferLen= NULL;
pfnZ_EnumNetPrinter			Z_EnumNetPrinter		= NULL;
pfnZ_CreateNetPort			Z_CreateNetPort			= NULL;
pfnZ_Prn_Text_TrueType_Uni	Z_Prn_Text_TrueType_Uni = NULL;
pfnZ_Prn_Text_TrueType_UniB	Z_Prn_Text_TrueType_UniB= NULL;
pfnZ_GetUSBDeviceInfo		Z_GetUSBDeviceInfo		= NULL;
pfnZ_Set_EncryptionKey		Z_Set_EncryptionKey		= NULL;
pfnZ_Check_EncryptionKey	Z_Check_EncryptionKey	= NULL;
pfnZ_Set_CommTimeout		Z_Set_CommTimeout		= NULL;
pfnZ_Get_CommTimeout		Z_Get_CommTimeout		= NULL;
pfnZ_Set_LabelForSmartPrint	Z_Set_LabelForSmartPrint	= NULL;
// PPLZDLL Function Declaration end

// CVC_2005Dlg ��ܤ��

CVC_2005Dlg::CVC_2005Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVC_2005Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	// Load Library start
	VERIFY(hPPLZ = ::LoadLibrary("WINPPLZ.DLL"));
	VERIFY(Z_Bar2d_Maxi = (pfnZ_Bar2d_Maxi) ::GetProcAddress(hPPLZ,"Z_Bar2d_Maxi"));
	VERIFY(Z_Bar2d_PDF417 = (pfnZ_Bar2d_PDF417) ::GetProcAddress(hPPLZ,"Z_Bar2d_PDF417"));
	VERIFY(Z_Bar2d_DataMatrix = (pfnZ_Bar2d_DataMatrix) ::GetProcAddress(hPPLZ,"Z_Bar2d_DataMatrix"));
	VERIFY(Z_ClosePrn = (pfnZ_ClosePrn) ::GetProcAddress(hPPLZ,"Z_ClosePrn"));
	VERIFY(Z_CreatePrn = (pfnZ_CreatePrn) ::GetProcAddress(hPPLZ,"Z_CreatePrn"));
	VERIFY(Z_Set_FlashMemory = (pfnZ_Set_FlashMemory) ::GetProcAddress(hPPLZ,"Z_Set_FlashMemory"));
	VERIFY(Z_Set_Format_New = (pfnZ_Set_Format_New) ::GetProcAddress(hPPLZ,"Z_Set_Format_New"));
	VERIFY(Z_Del_Format = (pfnZ_Del_Format) ::GetProcAddress(hPPLZ,"Z_Del_Format"));
	VERIFY(Z_Del_Graphic = (pfnZ_Del_Graphic) ::GetProcAddress(hPPLZ,"Z_Del_Graphic"));
	VERIFY(Z_Draw_Box = (pfnZ_Draw_Box) ::GetProcAddress(hPPLZ,"Z_Draw_Box"));
	VERIFY(Z_Draw_Line = (pfnZ_Draw_Line) ::GetProcAddress(hPPLZ,"Z_Draw_Line"));
	VERIFY(Z_Get_DLL_Version = (pfnZ_Get_DLL_Version) ::GetProcAddress(hPPLZ,"Z_Get_DLL_Version"));
	VERIFY(Z_Get_DLL_VersionA = (pfnZ_Get_DLL_VersionA) ::GetProcAddress(hPPLZ,"Z_Get_DLL_VersionA"));
	VERIFY(Z_Get_Graphic_ColorBMP = (pfnZ_Get_Graphic_ColorBMP) ::GetProcAddress(hPPLZ,"Z_Get_Graphic_ColorBMP"));
	VERIFY(Z_Get_Graphic_ColorBMPEx = (pfnZ_Get_Graphic_ColorBMPEx) ::GetProcAddress(hPPLZ,"Z_Get_Graphic_ColorBMPEx"));
	VERIFY(Z_Get_Graphic_ColorBMP_HBitmap = (pfnZ_Get_Graphic_ColorBMP_HBitmap) ::GetProcAddress(hPPLZ,"Z_Get_Graphic_ColorBMP_HBitmap"));
	VERIFY(Z_Initial_Setting = (pfnZ_Initial_Setting) ::GetProcAddress(hPPLZ,"Z_Initial_Setting"));
	VERIFY(Z_WriteData = (pfnZ_WriteData) ::GetProcAddress(hPPLZ,"Z_WriteData"));
	VERIFY(Z_ReadData = (pfnZ_ReadData) ::GetProcAddress(hPPLZ,"Z_ReadData"));
	VERIFY(Z_Load_Graphic = (pfnZ_Load_Graphic) ::GetProcAddress(hPPLZ,"Z_Load_Graphic"));
	VERIFY(Z_Open_ChineseFont = (pfnZ_Open_ChineseFont) ::GetProcAddress(hPPLZ,"Z_Open_ChineseFont"));
	VERIFY(Z_Print_Form = (pfnZ_Print_Form) ::GetProcAddress(hPPLZ,"Z_Print_Form"));
	VERIFY(Z_Print_Out = (pfnZ_Print_Out) ::GetProcAddress(hPPLZ,"Z_Print_Out"));
	VERIFY(Z_Prn_Barcode = (pfnZ_Prn_Barcode) ::GetProcAddress(hPPLZ,"Z_Prn_Barcode"));
	VERIFY(Z_Prn_Text = (pfnZ_Prn_Text) ::GetProcAddress(hPPLZ,"Z_Prn_Text"));
	VERIFY(Z_Prn_Text_Chinese = (pfnZ_Prn_Text_Chinese) ::GetProcAddress(hPPLZ,"Z_Prn_Text_Chinese"));
	VERIFY(Z_Prn_Text_TrueType = (pfnZ_Prn_Text_TrueType) ::GetProcAddress(hPPLZ,"Z_Prn_Text_TrueType"));
	VERIFY(Z_Prn_Text_TrueType_W = (pfnZ_Prn_Text_TrueType_W) ::GetProcAddress(hPPLZ,"Z_Prn_Text_TrueType_W"));
	VERIFY(Z_Clear_Memory = (pfnZ_Clear_Memory) ::GetProcAddress(hPPLZ,"Z_Clear_Memory"));
	VERIFY(Z_Clear_MemoryEx = (pfnZ_Clear_MemoryEx) ::GetProcAddress(hPPLZ,"Z_Clear_MemoryEx"));
	VERIFY(Z_Set_Backfeed = (pfnZ_Set_Backfeed) ::GetProcAddress(hPPLZ,"Z_Set_Backfeed"));
	VERIFY(Z_Set_Darkness = (pfnZ_Set_Darkness) ::GetProcAddress(hPPLZ,"Z_Set_Darkness"));
	VERIFY(Z_Set_DebugDialog = (pfnZ_Set_DebugDialog) ::GetProcAddress(hPPLZ,"Z_Set_DebugDialog"));
	VERIFY(Z_Set_Label = (pfnZ_Set_Label) ::GetProcAddress(hPPLZ,"Z_Set_Label"));
	VERIFY(Z_Set_Mode = (pfnZ_Set_Mode) ::GetProcAddress(hPPLZ,"Z_Set_Mode"));
	VERIFY(Z_Set_Origin = (pfnZ_Set_Origin) ::GetProcAddress(hPPLZ,"Z_Set_Origin"));
	VERIFY(Z_Set_Paper = (pfnZ_Set_Paper) ::GetProcAddress(hPPLZ,"Z_Set_Paper"));
	VERIFY(Z_Set_Prncomport = (pfnZ_Set_Prncomport) ::GetProcAddress(hPPLZ,"Z_Set_Prncomport"));
	VERIFY(Z_Set_Prncomport_PC = (pfnZ_Set_Prncomport_PC) ::GetProcAddress(hPPLZ,"Z_Set_Prncomport_PC"));
	VERIFY(Z_Set_Reset = (pfnZ_Set_Reset) ::GetProcAddress(hPPLZ,"Z_Set_Reset"));
	VERIFY(Z_Set_Speed = (pfnZ_Set_Speed) ::GetProcAddress(hPPLZ,"Z_Set_Speed"));
	VERIFY(Z_Set_TPH = (pfnZ_Set_TPH) ::GetProcAddress(hPPLZ,"Z_Set_TPH"));
	VERIFY(Z_Set_Unit = (pfnZ_Set_Unit) ::GetProcAddress(hPPLZ,"Z_Set_Unit"));
	VERIFY(Z_Set_Gap = (pfnZ_Set_Gap) ::GetProcAddress(hPPLZ,"Z_Set_Gap"));
	VERIFY(Z_Set_ProcessDlg = (pfnZ_Set_ProcessDlg) ::GetProcAddress(hPPLZ,"Z_Set_ProcessDlg"));
	VERIFY(Z_Set_ErrorDlg = (pfnZ_Set_ErrorDlg) ::GetProcAddress(hPPLZ,"Z_Set_ErrorDlg"));
	VERIFY(Z_Bar2d_QRCode = (pfnZ_Bar2d_QRCode) ::GetProcAddress(hPPLZ,"Z_Bar2d_QRCode"));
	VERIFY(Z_Set_PrintWidth = (pfnZ_Set_PrintWidth) ::GetProcAddress(hPPLZ,"Z_Set_PrintWidth"));
	VERIFY(Z_Print_OutQuality = (pfnZ_Print_OutQuality) ::GetProcAddress(hPPLZ,"Z_Print_OutQuality"));
	VERIFY(Z_GetUSBBufferLen = (pfnZ_GetUSBBufferLen) ::GetProcAddress(hPPLZ,"Z_GetUSBBufferLen"));
	VERIFY(Z_EnumUSB = (pfnZ_EnumUSB) ::GetProcAddress(hPPLZ,"Z_EnumUSB"));
	VERIFY(Z_CreateUSBPort = (pfnZ_CreateUSBPort) ::GetProcAddress(hPPLZ,"Z_CreateUSBPort"));
	VERIFY(Z_CreatePort = (pfnZ_CreatePort) ::GetProcAddress(hPPLZ, "Z_CreatePort"));
	VERIFY(Z_Set_Mirror = (pfnZ_Set_Mirror) ::GetProcAddress(hPPLZ,"Z_Set_Mirror"));
	VERIFY(Z_Bar2d_RSS = (pfnZ_Bar2d_RSS) ::GetProcAddress(hPPLZ,"Z_Bar2d_RSS"));
	VERIFY(Z_GetNetPrinterBufferLen = (pfnZ_GetNetPrinterBufferLen) ::GetProcAddress(hPPLZ,"Z_GetNetPrinterBufferLen"));
	VERIFY(Z_EnumNetPrinter = (pfnZ_EnumNetPrinter) ::GetProcAddress(hPPLZ,"Z_EnumNetPrinter"));
	VERIFY(Z_CreateNetPort = (pfnZ_CreateNetPort) ::GetProcAddress(hPPLZ,"Z_CreateNetPort"));
	VERIFY(Z_Prn_Text_TrueType_Uni = (pfnZ_Prn_Text_TrueType_Uni) ::GetProcAddress(hPPLZ,"Z_Prn_Text_TrueType_Uni"));
	VERIFY(Z_Prn_Text_TrueType_UniB = (pfnZ_Prn_Text_TrueType_UniB) ::GetProcAddress(hPPLZ,"Z_Prn_Text_TrueType_UniB"));
	VERIFY(Z_GetUSBDeviceInfo = (pfnZ_GetUSBDeviceInfo) ::GetProcAddress(hPPLZ,"Z_GetUSBDeviceInfo"));
	VERIFY(Z_Set_EncryptionKey = (pfnZ_Set_EncryptionKey) ::GetProcAddress(hPPLZ,"Z_Set_EncryptionKey"));
	VERIFY(Z_Check_EncryptionKey = (pfnZ_Check_EncryptionKey) ::GetProcAddress(hPPLZ,"Z_Check_EncryptionKey"));
	VERIFY(Z_Set_CommTimeout = (pfnZ_Set_CommTimeout) ::GetProcAddress(hPPLZ,"Z_Set_CommTimeout"));
	VERIFY(Z_Get_CommTimeout = (pfnZ_Get_CommTimeout) ::GetProcAddress(hPPLZ,"Z_Get_CommTimeout"));
	VERIFY(Z_Set_LabelForSmartPrint = (pfnZ_Set_LabelForSmartPrint) ::GetProcAddress(hPPLZ,"Z_Set_LabelForSmartPrint"));
	// Load Library end
}

CVC_2005Dlg::~CVC_2005Dlg()
{
	VERIFY(::FreeLibrary(hPPLZ));
}

void CVC_2005Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CVC_2005Dlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CVC_2005Dlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CVC_2005Dlg �T���B�z�`��

BOOL CVC_2005Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	//ShowWindow(SW_MINIMIZE);

	// TODO: �b���[�J�B�~����l�]�w

	return TRUE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CVC_2005Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CVC_2005Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CVC_2005Dlg::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	// open port.
	int nLen, ret, sw;
	char *ver, *pbuf = new char[128];
	CString strmsg;

	// dll version.
	ver = Z_Get_DLL_Version(0);

	// search port.
	nLen = Z_GetUSBBufferLen() + 1;
	strmsg.Format("DLL %s\r\n", ver);
	if (nLen > 1)
	{
		char *buf1,*buf2;
		int len1 = 128, len2 = 128;
		buf1 = new char[len1];
		buf2 = new char[len2];
		Z_EnumUSB(pbuf);
		Z_GetUSBDeviceInfo(1, buf1, &len1, buf2, &len2);
		sw = 1;
		if (sw) {
			ret = Z_CreatePrn(12, buf2);// open usb.
		}
		else {
			ret = Z_CreateUSBPort(1);// must call Z_GetUSBBufferLen() function fisrt.
		}
		if (0 != ret) {
			strmsg += "Open USB fail!";
		}
		else {
			strmsg += "Open USB:\r\nDevice name: ";
			strmsg += buf1;
			strmsg += "\r\nDevice path: ";
			strmsg += buf2;
			//sw = 2;
			if (2 == sw) {
				//get host status.
				Z_WriteData(1, "~HS\r\n", 5);//~HS
				ret = Z_ReadData(pbuf, 82, 1000);
			}
		}
	}
	else
	{
		CreateDirectory(szSavePath, NULL);
		ret = Z_CreatePrn(0, szSaveFile);// open file.
		strmsg += "Open ";
		strmsg += szSaveFile;
		if (0 != ret) {
			strmsg += " file fail!";
		}
		else {
			strmsg += " file succeed!";
		}
	}
	MessageBox(strmsg);
	if (0 != ret)
		return;

	// sample setting.
	Z_Set_DebugDialog(1);
	Z_Set_Origin(0);
	Z_Set_Paper('Y');
	Z_Set_TPH('D');
	Z_Set_Unit('D');//dot.
	Z_Set_Darkness(8);
	Z_Set_Label(203*3);
	Z_Set_PrintWidth(203*4);
	Z_Clear_Memory();// clear memory.
	Z_WriteData(0, sznop2, (DWORD)strlen(sznop2));
	Z_WriteData(1, sznop1, (DWORD)strlen(sznop1));
	//When using standard label, and the printer is Intelli Print mode or Smart Print mode,
	//When calling this function and giving the correct label information,
	//the immediate print function will be enabled according to the label length setting.
	Z_Set_LabelForSmartPrint(254*3, 30);//label information: length= 3 * 25.4 mm, gap= 3 mm.

	//draw box.
	Z_Draw_Box(20, 20, 760, 560, 4);
	Z_Draw_Line(400, 20, 4, 560);

	//print text, true type text.
	Z_Prn_Text(30, 40, 1, 'D', 1, 1, 0, "PPLZ Lib Example");
	Z_Prn_Text_TrueType(30,100,30,"Arial",1,400,0,0,0,"AA","TrueType Font", 0);//save in printer.
	Z_Prn_Text_TrueType_W(30,160,20,20,"Times New Roman",1,400,0,0,0,"AB","TT_W: �h�r������", 0);
	Z_Prn_Text_TrueType_Uni(30,220,30,"Times New Roman",1,400,0,0,0,"AC",L"TT_Uni: �h�r������",1, 0);//UTF-16
	strcpy(pbuf, "\xFF\xFE");//UTF-16.
	memcpy(&pbuf[2], (char *)L"TT_UniB: �h�r������", 15*2);//copy mutil byte.
	Z_Prn_Text_TrueType_UniB(30,280,30,"Times New Roman",1,400,0,0,0,"AD",pbuf,0, 0);//Byte Order Mark.

	//barcode.
	Z_Prn_Barcode(420, 100, 1, 2, 3, 40, '3', 1, "1234", 'N','Y','N','N','N');//have a counter
	Z_Bar2d_QRCode(420, 190, 2, 3, 3, 1, "QR CODE", 0);

	//picture.
	Z_Get_Graphic_ColorBMP(420, 280, 0, "bb.bmp");// Color bmp file to ram.
	Z_Get_Graphic_ColorBMPEx(420, 330, 200, 150, 2, 0, "bb1", "bb.bmp");//180 angle
	HANDLE himage = LoadImage(NULL,"bb.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
	Z_Get_Graphic_ColorBMP_HBitmap(630, 280, 250, 80, 1, 0, "bb2", (HBITMAP)himage);//90 angle.
	if (himage)
		DeleteObject(himage);

	// output.
	Z_Print_Out(2,1);// copy 2.

	// close port.
	Z_ClosePrn();
}
