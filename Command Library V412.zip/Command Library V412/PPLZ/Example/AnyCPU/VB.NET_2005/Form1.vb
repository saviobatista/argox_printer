Public Class Form1
    Const IMAGE_BITMAP = 0
    Const LR_LOADFROMFILE = &H10
    Private Declare Function LoadImage Lib "user32" Alias "LoadImageA" (ByVal hInst As Integer, _
            ByVal lpsz As String, ByVal un1 As Integer, ByVal n1 As Integer, ByVal n2 As Integer, _
            ByVal un2 As Integer) As Integer
    Private Declare Function DeleteObject Lib "Gdi32" (ByVal ho As Integer) As Integer
    Const szSavePath As String = "C:\Argox"
    Const szSaveFile As String = "C:\Argox\PPLZ_Example.Prn"
    Const sznop1 As String = "nop_front" + vbCrLf
    Const sznop2 As String = "nop_middle" + vbCrLf
    Private Declare Function Z_Bar2d_Maxi Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal nMode As Integer, ByVal nSymbol As Integer, ByVal nTotal As Integer, _
            ByVal nClass As Integer, ByVal nCountry As Integer, ByVal cZipCode1 As String, _
            ByVal cZipCode2 As String, ByVal data As String, ByVal increase As Integer) As Integer
    Private Declare Function Z_Bar2d_PDF417 Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal o As Integer, ByVal h As Integer, ByVal s As Integer, _
            ByVal c As Integer, ByVal r As Integer, ByVal t As Integer, ByVal narrow As Integer, _
            ByVal data As String, ByVal increase As Integer) As Integer
    Private Declare Function Z_Bar2d_DataMatrix Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal o As Integer, ByVal h As Integer, ByVal c As Integer, ByVal r As Integer, _
            ByVal data As String, ByVal increase As Integer) As Integer
    Private Declare Sub Z_ClosePrn Lib "WINPPLZ.DLL" ()
    Private Declare Function Z_CreatePrn Lib "WINPPLZ.DLL" (ByVal selection As Integer, _
            ByVal filename As String) As Integer
    Private Declare Function Z_Set_FlashMemory Lib "WINPPLZ.DLL" (ByVal Status As Integer) As Integer
    Private Declare Sub Z_Set_Format_New Lib "WINPPLZ.DLL" (ByVal FormatName As String)
    Private Declare Function Z_Del_Format Lib "WINPPLZ.DLL" (ByVal nMem As Integer, _
            ByVal formname As String) As Integer
    Private Declare Function Z_Del_Graphic Lib "WINPPLZ.DLL" (ByVal memory As Integer, _
            ByVal graphicname As String) As Integer
    Private Declare Function Z_Draw_Box Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal width As Integer, ByVal height As Integer, ByVal thickness As Integer) As Integer
    Private Declare Function Z_Draw_Line Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal width As Integer, ByVal height As Integer) As Integer
    Private Declare Function Z_Get_DLL_Version Lib "WINPPLZ.DLL" (ByVal nShowmessage As Integer) As String
    Private Declare Function Z_Get_DLL_VersionA Lib "WINPPLZ.DLL" (ByVal nShowmessage As Integer) As Integer
    Private Declare Function Z_Get_Graphic_ColorBMP Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal mem As Integer, ByVal filename As String) As Integer
    Private Declare Function Z_Get_Graphic_ColorBMPEx Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal mem_mode As Integer, ByVal id_name As String, _
            ByVal filename As String) As Integer
    Private Declare Function Z_Get_Graphic_ColorBMP_HBitmap Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, _
            ByVal rotate As Integer, ByVal mem_mode As Integer, ByVal id_name As String, _
            ByVal hbm As Integer) As Integer
    Private Declare Function Z_Initial_Setting Lib "WINPPLZ.DLL" (ByVal mode As Integer, _
            ByVal Source As String) As Integer
    Private Declare Function Z_WriteData Lib "WINPPLZ.DLL" (ByVal IsImmediate As Integer, _
            ByVal pbuf As Byte(), ByVal length As ULong) As Integer
    Private Declare Function Z_ReadData Lib "WINPPLZ.DLL" (ByVal pbuf As Byte(), ByVal length As ULong, _
            ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function Z_Load_Graphic Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal memory As Integer, ByVal graphicname As String, _
            ByVal hori As Integer, ByVal vert As Integer) As Integer
    Private Declare Function Z_Open_ChineseFont Lib "WINPPLZ.DLL" (ByVal path As String) As Integer
    Private Declare Function Z_Print_Form Lib "WINPPLZ.DLL" (ByVal copies As Integer, _
            ByVal labset As Integer, ByVal mem As Integer, ByVal formout As String) As Integer
    Private Declare Function Z_Print_Out Lib "WINPPLZ.DLL" (ByVal sets As Integer, _
            ByVal copies As Integer) As Integer
    Private Declare Function Z_Prn_Barcode Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal ori As Integer, ByVal narrow As Integer, _
            ByVal width As Integer, ByVal height As Integer, ByVal bar_type As Byte, _
            ByVal increase As Integer, ByVal data As String, ByVal p1 As Byte, ByVal p2 As Byte, _
            ByVal p3 As Byte, ByVal p4 As Byte, ByVal p5 As Byte) As Integer
    Private Declare Function Z_Prn_Text Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
            ByVal ori As Integer, ByVal font As Byte, ByVal height As Integer, _
            ByVal width As Integer, ByVal numeric As Integer, ByVal data As String) As Integer
    Private Declare Function Z_Prn_Text_Chinese Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal fonttype As Integer, ByVal id_name As String, _
            ByVal data As String, ByVal mem As Integer) As Integer
    Private Declare Function Z_Prn_Text_TrueType Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As String, ByVal mem As Integer) As Integer
    Private Declare Function Z_Prn_Text_TrueType_W Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FHeight As Integer, ByVal FWidth As Integer, _
            ByVal FType As String, ByVal Fspin As Integer, ByVal FWeight As Integer, _
            ByVal FItalic As Integer, ByVal FUnline As Integer, ByVal FStrikeOut As Integer, _
            ByVal id_name As String, ByVal data As String, ByVal mem As Integer) As Integer
    Private Declare Sub Z_Clear_Memory Lib "WINPPLZ.DLL" ()
    Private Declare Sub Z_Clear_MemoryEx Lib "WINPPLZ.DLL" (ByVal nMode As Integer)
    Private Declare Function Z_Set_Backfeed Lib "WINPPLZ.DLL" (ByVal nDistance As Integer) As Integer
    Private Declare Function Z_Set_Darkness Lib "WINPPLZ.DLL" (ByVal darkness As Integer) As Integer
    Private Declare Function Z_Set_DebugDialog Lib "WINPPLZ.DLL" (ByVal nEnable As Integer) As Integer
    Private Declare Function Z_Set_Label Lib "WINPPLZ.DLL" (ByVal Length As Integer) As Integer
    Private Declare Function Z_Set_Mode Lib "WINPPLZ.DLL" (ByVal mode As Byte) As Integer
    Private Declare Function Z_Set_Origin Lib "WINPPLZ.DLL" (ByVal y As Integer) As Integer
    Private Declare Function Z_Set_Paper Lib "WINPPLZ.DLL" (ByVal mode As Byte) As Integer
    Private Declare Function Z_Set_Prncomport Lib "WINPPLZ.DLL" (ByVal baud As Integer, _
            ByVal parity As Integer, ByVal data As Integer, ByVal stopbit As Integer) As Integer
    Private Declare Function Z_Set_Prncomport_PC Lib "WINPPLZ.DLL" (ByVal nBaudRate As Integer, _
            ByVal nBytesSize As Integer, ByVal nParity As Integer, ByVal nStopBits As Integer, _
            ByVal nDsr As Integer, ByVal nCts As Integer, ByVal nXonXoff As Integer) As Integer
    Private Declare Sub Z_Set_Reset Lib "WINPPLZ.DLL" ()
    Private Declare Function Z_Set_Speed Lib "WINPPLZ.DLL" (ByVal speed As Integer) As Integer
    Private Declare Function Z_Set_TPH Lib "WINPPLZ.DLL" (ByVal mode As Byte) As Integer
    Private Declare Function Z_Set_Unit Lib "WINPPLZ.DLL" (ByVal Unit As Byte) As Integer
    Private Declare Function Z_Set_Gap Lib "WINPPLZ.DLL" (ByVal nPatern As Integer, _
            ByVal nGaplen As Integer) As Integer
    Private Declare Function Z_Set_ProcessDlg Lib "WINPPLZ.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function Z_Set_ErrorDlg Lib "WINPPLZ.DLL" (ByVal nShow As Integer) As Integer
    Private Declare Function Z_Bar2d_QRCode Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal nModel As Integer, ByVal nMagni As Integer, _
            ByVal nErr_Cor As Integer, ByVal nInput As Integer, ByVal data As String, _
            ByVal increase As Integer) As Integer
    Private Declare Function Z_Set_PrintWidth Lib "WINPPLZ.DLL" (ByVal nDotWidth As Integer) As Integer
    Private Declare Function Z_Print_OutQuality Lib "WINPPLZ.DLL" (ByVal nTotal As Integer, _
            ByVal sets As Integer, ByVal copies As Integer, ByVal nPause As Integer) As Integer
    Private Declare Function Z_GetUSBBufferLen Lib "WINPPLZ.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function Z_EnumUSB Lib "WINPPLZ.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function Z_CreateUSBPort Lib "WINPPLZ.DLL" (ByVal nPort As Integer) As Integer
    Private Declare Function Z_CreatePort Lib "WINPPLZ.DLL" (ByVal nPortType As Integer, _
            ByVal nPort As Integer, ByVal filename As String) As Integer
    Private Declare Function Z_Set_Mirror Lib "WINPPLZ.DLL" (ByVal direction As Byte) As Integer
    Private Declare Function Z_Bar2d_RSS Lib "WINPPLZ.DLL" (ByVal x As Integer, ByVal y As Integer, _
    ByVal ori As Byte, ByVal rtype As Integer, ByVal mag As Integer, ByVal height As Integer, _
            ByVal seg As Integer, ByVal data1 As String, ByVal data2 As String) As Integer
    Private Declare Function Z_GetNetPrinterBufferLen Lib "WINPPLZ.DLL" () As Integer
    'buf is buffer address, so can use "ByVal buf As String" . You can reference VB_6 example.
    Private Declare Function Z_EnumNetPrinter Lib "WINPPLZ.DLL" (ByVal buf As Byte()) As Integer
    Private Declare Function Z_CreateNetPort Lib "WINPPLZ.DLL" (ByVal nPort As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function Z_Prn_Text_TrueType_Uni Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As Byte(), ByVal format As Integer, ByVal mem_mode As Integer) As Integer
    'data is buffer address, so can use "ByVal data As Integer" or "ByRef data As Byte". You can reference VB_6 example.
    Private Declare Function Z_Prn_Text_TrueType_UniB Lib "WINPPLZ.DLL" (ByVal x As Integer, _
            ByVal y As Integer, ByVal FSize As Integer, ByVal FType As String, _
            ByVal Fspin As Integer, ByVal FWeight As Integer, ByVal FItalic As Integer, _
            ByVal FUnline As Integer, ByVal FStrikeOut As Integer, ByVal id_name As String, _
            ByVal data As Byte(), ByVal format As Integer, ByVal mem_mode As Integer) As Integer
    'pDeviceName and pDevicePath are buffer address, so can use "ByVal pDeviceName As String" and "ByVal pDevicePath As String". You can reference VB_6 example.
    Private Declare Function Z_GetUSBDeviceInfo Lib "WINPPLZ.DLL" (ByVal nPort As Integer, _
            ByVal pDeviceName As Byte(), ByRef pDeviceNameLen As Integer, _
            ByVal pDevicePath As Byte(), ByRef pDevicePathLen As Integer) As Integer
    Private Declare Function Z_Set_EncryptionKey Lib "WINPPLZ.DLL" (ByVal encryptionKey As String) As Integer
    Private Declare Function Z_Check_EncryptionKey Lib "WINPPLZ.DLL" (ByVal decodeKey As String, _
            ByVal encryptionKey As String, ByVal dwTimeoutms As ULong) As Integer
    Private Declare Function Z_Set_CommTimeout Lib "WINPPLZ.DLL" (ByVal ReadTotalTimeoutConstant As Integer, _
            ByVal WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function Z_Get_CommTimeout Lib "WINPPLZ.DLL" (ByRef ReadTotalTimeoutConstant As Integer, _
            ByRef WriteTotalTimeoutConstant As Integer) As Integer
    Private Declare Function Z_Set_LabelForSmartPrint Lib "WINPPLZ.DLL" (ByVal lablength As Integer, _
            ByVal gaplength As Integer) As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Test code start
        ' open port.
        Dim nLen As Integer
        Dim ret As Integer
        Dim sw As Integer
        Dim pbuf(128) As Byte
        Dim nVersion, nMainVersion, nSubVersion As Integer
        Dim strmsg As String
        Dim encAscII = System.Text.Encoding.ASCII
        Dim encUnicode = System.Text.Encoding.Unicode

        ' dll version.
        nVersion = Z_Get_DLL_VersionA(0)
        nMainVersion = nVersion / 100
        nSubVersion = nVersion Mod 100

        ' search port.
        nLen = Z_GetUSBBufferLen() + 1
        strmsg = "DLL Ver: " + Str(nMainVersion) + "." + Str(nSubVersion) + vbCrLf
        If nLen > 1 Then
            Dim buf1() As Byte
            Dim buf2() As Byte
            Dim len1 As Integer = 128
            Dim len2 As Integer = 128
            ReDim buf1(len1) ' buf1= New Byte(len1) {}
            ReDim buf2(len2) ' buf2= New Byte(len2) {}
            Call Z_EnumUSB(pbuf)
            Call Z_GetUSBDeviceInfo(1, buf1, len1, buf2, len2)
            sw = 1
            If sw Then
                ret = Z_CreatePrn(12, encAscII.GetString(buf2, 0, len2)) ' open usb.
            Else
                ret = Z_CreateUSBPort(1) ' must call Z_GetUSBBufferLen() function fisrt.
            End If
            If 0 < ret Then
                strmsg += "Open USB fail!"
            Else
                strmsg += "Open USB:" + vbCrLf + "Device name: "
                strmsg += encAscII.GetString(buf1, 0, len1)
                strmsg += vbCrLf + "Device path: "
                strmsg += encAscII.GetString(buf2, 0, len2)
                'sw = 2
                If 2 = sw Then
                    'get host status.
                    Z_WriteData(1, encAscII.GetBytes("~HS\r\n"), 5)   '~HS
                    ret = Z_ReadData(pbuf, 82, 1000)
                End If
            End If
        Else
            System.IO.Directory.CreateDirectory(szSavePath)
            ret = Z_CreatePrn(0, szSaveFile) ' open file.
            strmsg += "Open "
            strmsg += szSaveFile
            If 0 < ret Then
                strmsg += " file fail!"
            Else
                strmsg += " file succeed!"
            End If
        End If
        MessageBox.Show(strmsg)
        If 0 < ret Then
            Exit Sub
        End If

        ' sample setting.
        Call Z_Set_DebugDialog(1)
        Call Z_Set_Origin(0)
        Call Z_Set_Paper(Asc("Y"))
        Call Z_Set_TPH(Asc("D"))
        Call Z_Set_Unit(Asc("D")) 'dot.
        Call Z_Set_Darkness(8)
        Call Z_Set_Label(203 * 3)
        Call Z_Set_PrintWidth(203 * 4)
        Call Z_Clear_Memory() ' clear memory.
        Call Z_WriteData(0, encAscII.GetBytes(sznop2), sznop2.Length)
        Call Z_WriteData(1, encAscII.GetBytes(sznop1), sznop1.Length)
        ' When using standard label, and the printer is Intelli Print mode or Smart Print mode,
        ' When calling this function and giving the correct label information,
        ' the immediate print function will be enabled according to the label length setting.
        Call Z_Set_LabelForSmartPrint(254 * 3, 30) ' label information: length= 3 * 25.4 mm, gap= 3 mm.

        'draw box.
        Call Z_Draw_Box(20, 20, 760, 560, 4)
        Call Z_Draw_Line(400, 20, 4, 560)

        'print text, true type text.
        Call Z_Prn_Text(30, 40, 1, Asc("D"), 1, 1, 0, "PPLZ Lib Example")
        Call Z_Prn_Text_TrueType(30, 100, 30, "Arial", 1, 400, 0, 0, 0, "AA", "TrueType Font", 0) 'save in printer.
        Call Z_Prn_Text_TrueType_W(30, 160, 20, 20, "Times New Roman", 1, 400, 0, 0, 0, "AB", "TT_W: �h�r������", 0)
        Call Z_Prn_Text_TrueType_Uni(30, 220, 30, "Times New Roman", 1, 400, 0, 0, 0, "AC", encUnicode.GetBytes("TT_Uni: �h�r������"), 1, 0) 'UTF-16
        pbuf(0) = 255 'UTF-16.
        pbuf(1) = 254
        encUnicode.GetBytes("TT_UniB: �h�r������", 0, 14, pbuf, 2) 'copy mutil byte.
        pbuf(30) = 0 'null.
        pbuf(31) = 0
        Call Z_Prn_Text_TrueType_UniB(30, 280, 30, "Times New Roman", 1, 400, 0, 0, 0, "AD", pbuf, 0, 0) 'Byte Order Mark.

        'barcode.
        Call Z_Prn_Barcode(420, 100, 1, 2, 3, 40, Asc("3"), 1, "1234", Asc("N"), Asc("Y"), Asc("N"), Asc("N"), Asc("N")) 'have a counter.
        Call Z_Bar2d_QRCode(420, 190, 2, 3, 3, 1, "QR CODE", 0)

        'picture.
        Call Z_Get_Graphic_ColorBMP(420, 280, 0, "bb.bmp") ' Color bmp file to ram.
        Call Z_Get_Graphic_ColorBMPEx(420, 330, 200, 150, 2, 0, "bb1", "bb.bmp") ' 180 angle.
        Dim himage As Integer
        himage = LoadImage(0, "bb.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE)
        Call Z_Get_Graphic_ColorBMP_HBitmap(630, 280, 250, 80, 1, 0, "bb2", himage) ' 90 angle.
        If himage Then
            Call DeleteObject(himage)
        End If

        ' output.
        Call Z_Print_Out(2, 1) ' copy 2.

        ' close port.
        Call Z_ClosePrn()
    End Sub
End Class
