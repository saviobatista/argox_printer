﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;//This is about DllImport.

namespace VCsharp_2005
{
    public partial class Form1 : Form
    {
        const uint IMAGE_BITMAP = 0;
        const uint LR_LOADFROMFILE = 16;
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern IntPtr LoadImage(IntPtr hinst, string lpszName, uint uType,
           int cxDesired, int cyDesired, uint fuLoad);
        [DllImport("Gdi32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern int DeleteObject(IntPtr ho);
        const string szSavePath = "C:\\Argox";
        const string szSaveFile = "C:\\Argox\\PPLZ_Example.Prn";
        const string sznop1 = "nop_front\r\n";
        const string sznop2 = "nop_middle\r\n";
        [DllImport("Winpplz.dll")]
        private static extern int Z_Bar2d_Maxi(int x, int y, int nMode, int nSymbol, int nTotal, 
            int nClass, int nCountry, string cZipCode1, string cZipCode2, string data, int increase);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Bar2d_PDF417(int x, int y, int o, int h, int s, int c, int r, 
            int t, int narrow, string data, int increase);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Bar2d_DataMatrix(int x, int y, int o, int h, int c, int r, 
            string data, int increase);            
        [DllImport("Winpplz.dll")]
        private static extern void Z_ClosePrn();
        [DllImport("Winpplz.dll")]
        private static extern int Z_CreatePrn(int selection, string filename);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_FlashMemory(int Status);
        [DllImport("Winpplz.dll")]
        private static extern void Z_Set_Format_New(string FormatName);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Del_Format(int memory, string formatname);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Del_Graphic(int memory, string graphicname);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Draw_Box(int x, int y, int width, int height, int thickness);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Draw_Line(int x, int y, int width, int height);
        [DllImport("Winpplz.dll")]
        private static extern IntPtr Z_Get_DLL_Version(int nShowMessage);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Get_DLL_VersionA(int nShowMessage);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Get_Graphic_ColorBMP(int x, int y, int mem_mode, 
            string filename);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Get_Graphic_ColorBMPEx(int x, int y, int nWidth, int nHeight,
            int rotate, int mem_mode, string id_name, string filename);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Get_Graphic_ColorBMP_HBitmap(int x, int y, int nWidth, int nHeight,
           int rotate, int mem_mode, string id_name, IntPtr hbm);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Initial_Setting(int Type, string Source);
        [DllImport("Winpplz.dll")]
        private static extern int Z_WriteData(int IsImmediate, byte[] pbuf, int length);
        [DllImport("Winpplz.dll")]
        private static extern int Z_ReadData(byte[] pbuf, int length, int dwTimeoutms);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Load_Graphic(int x, int y, int memory, string graphic_name, 
            int horizontal, int vertical);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Open_ChineseFont(string path);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Print_Form(int copies, int labset, int mem_mode, 
            string form_out);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Print_Out(int sets, int copies);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Barcode(int x, int y, int ori, int narrow, int width, 
            int height, char type, int increase, string data, char human1, char human2, 
            char human3, char human4, char human5);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text(int x, int y, int ori, char font, int height, 
            int width, int numeric, string data);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text_Chinese(int x, int y, int fonttype, string id_name, 
            string data, int mem_mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text_TrueType(int x, int y, int FSize, string FType, 
            int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut, string id_name, 
            string data, int mem_mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text_TrueType_W(int x, int y, int FHeight, int FWidth, 
            string FType, int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut, 
            string id_name, string data, int mem_mode);
        [DllImport("Winpplz.dll")]
        private static extern void Z_Clear_Memory();
        [DllImport("Winpplz.dll")]
        private static extern void Z_Clear_MemoryEx(int nMode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Backfeed(int nDistance);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Darkness(int darkness);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_DebugDialog(int nEnable);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Label(int Length);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Mode(char mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Origin(int y);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Paper(char mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Prncomport(int baud, int parity, int data, int stop);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Prncomport_PC(int nBaudRate, int nByteSize, int nParity, 
            int nStopBits, int nDsr, int nCts, int nXonXoff);
        [DllImport("Winpplz.dll")]
        private static extern void Z_Set_Reset();
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Speed(int print);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_TPH(char mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Unit(char Unit);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Gap(int nPatern, int nGap);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_ProcessDlg(int nShow);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_ErrorDlg(int nShow);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Bar2d_QRCode(int x, int y, int nModel, int nMagni, 
            int nErr_Cor, int nInput, string data, int increase);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_PrintWidth(int nDotwidth);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Print_OutQuality(int nTotal, int sets, int copies, int nPause);
        [DllImport("Winpplz.dll")]
        private static extern int Z_GetUSBBufferLen();
        [DllImport("Winpplz.dll")]
        private static extern int Z_EnumUSB(byte[] buf);
        [DllImport("Winpplz.dll")]
        private static extern int Z_CreateUSBPort(int nPort);
        [DllImport("Winpplz.dll")]
        private static extern int Z_CreatePort(int nPortType, int nPort, string filename);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_Mirror(char direction);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Bar2d_RSS(int x, int y, char ori, int rtype, int mag, 
            int height, int seg, string data1, string data2);
        [DllImport("Winpplz.dll")]
        private static extern int Z_GetNetPrinterBufferLen();
        [DllImport("Winpplz.dll")]
        private static extern int Z_EnumNetPrinter(byte[] buf);
        [DllImport("Winpplz.dll")]
        private static extern int Z_CreateNetPort(int nPort);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text_TrueType_Uni(int x, int y, int FSize, string FType, 
            int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut, string id_name, 
            byte[] data, int format, int mem_mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Prn_Text_TrueType_UniB(int x, int y, int FSize, string FType, 
            int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut, string id_name, 
            byte[] data, int format, int mem_mode);
        [DllImport("Winpplz.dll")]
        private static extern int Z_GetUSBDeviceInfo(int nPort, byte[] pDeviceName, 
            out int pDeviceNameLen, byte[] pDevicePath, out int pDevicePathLen);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_EncryptionKey(string encryptionKey);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Check_EncryptionKey(string decodeKey, string encryptionKey, 
            int dwTimeoutms);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_CommTimeout(int ReadTotalTimeoutConstant, int WriteTotalTimeoutConstant);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Get_CommTimeout(out int ReadTotalTimeoutConstant, out int WriteTotalTimeoutConstant);
        [DllImport("Winpplz.dll")]
        private static extern int Z_Set_LabelForSmartPrint(int lablength, int gaplength);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Test code start
	        // open port.
            int nLen, ret, sw;
            byte[] pbuf = new byte[128];
            string strmsg;
            IntPtr ver;
            System.Text.Encoding encAscII = System.Text.Encoding.ASCII;
            System.Text.Encoding encUnicode = System.Text.Encoding.Unicode;

	        // dll version.
	        ver = Z_Get_DLL_Version(0);

	        // search port.
	        nLen = Z_GetUSBBufferLen() + 1;
            strmsg = "DLL ";
            strmsg += Marshal.PtrToStringAnsi(ver);
            strmsg += "\r\n";
	        if (nLen > 1)
	        {
                byte[] buf1, buf2;
		        int len1 = 128, len2 = 128;
                buf1 = new byte[len1];
                buf2 = new byte[len2];
		        Z_EnumUSB(pbuf);
		        Z_GetUSBDeviceInfo(1, buf1, out len1, buf2, out len2);
                sw = 1;
                if (1 == sw)
                {
                    ret = Z_CreatePrn(12, encAscII.GetString(buf2, 0, len2));// open usb.
                }
                else
                {
                    ret = Z_CreateUSBPort(1);// must call Z_GetUSBBufferLen() function fisrt.
                }
		        if (0 != ret) {
                    strmsg += "Open USB fail!";
		        }
		        else {
                    strmsg += "Open USB:\r\nDevice name: ";
                    strmsg += encAscII.GetString(buf1, 0, len1);
                    strmsg += "\r\nDevice path: ";
                    strmsg += encAscII.GetString(buf2, 0, len2);
                    //sw = 2;
                    if (2 == sw)
                    {
                        //get host status.
                        Z_WriteData(1, encAscII.GetBytes("~HS\r\n"), 5);//~HS
                        ret = Z_ReadData(pbuf, 82, 1000);
                    }
		        }
	        }
	        else
	        {
                System.IO.Directory.CreateDirectory(szSavePath);
		        ret = Z_CreatePrn(0, szSaveFile);// open file.
                strmsg += "Open ";
                strmsg += szSaveFile;
		        if (0 != ret) {
                    strmsg += " file fail!";
		        }
		        else {
                    strmsg += " file succeed!";
		        }
	        }
            MessageBox.Show(strmsg);
	        if (0 != ret)
		        return;

	        // sample setting.
	        Z_Set_DebugDialog(1);
	        Z_Set_Origin(0);
	        Z_Set_Paper('Y');
	        Z_Set_TPH('D');
	        Z_Set_Unit('D');//dot.
	        Z_Set_Darkness(8);
	        Z_Set_Label(203*3);
	        Z_Set_PrintWidth(203*4);
	        Z_Clear_Memory();// clear memory.
            Z_WriteData(0, encAscII.GetBytes(sznop2), sznop2.Length);
            Z_WriteData(1, encAscII.GetBytes(sznop1), sznop1.Length);
            //When using standard label, and the printer is Intelli Print mode or Smart Print mode,
            //When calling this function and giving the correct label information,
            //the immediate print function will be enabled according to the label length setting.
            Z_Set_LabelForSmartPrint(254 * 3, 30);//label information: length= 3 * 25.4 mm, gap= 3 mm.

	        //draw box.
	        Z_Draw_Box(20, 20, 760, 560, 4);
	        Z_Draw_Line(400, 20, 4, 560);

	        //print text, true type text.
	        Z_Prn_Text(30, 40, 1, 'D', 1, 1, 0, "PPLZ Lib Example");
	        Z_Prn_Text_TrueType(30,100,30,"Arial",1,400,0,0,0,"AA","TrueType Font", 0);//save in printer.
	        Z_Prn_Text_TrueType_W(30,160,20,20,"Times New Roman",1,400,0,0,0,"AB","TT_W: 多字元測試", 0);
	        Z_Prn_Text_TrueType_Uni(30,220,30,"Times New Roman",1,400,0,0,0,"AC",Encoding.Unicode.GetBytes("TT_Uni: 多字元測試"),1, 0);//UTF-16
            encUnicode.GetBytes("\xFEFF", 0, 1, pbuf, 0);//UTF-16.//pbuf[0]=0xFF,pbuf[1]=0xFE;
            encUnicode.GetBytes("TT_UniB: 多字元測試", 0, 14, pbuf, 2);//copy mutil byte.
            encUnicode.GetBytes("\x0000", 0, 1, pbuf, 30);//null.//pbuf[30]=0x00,pbuf[31]=0x00;
	        Z_Prn_Text_TrueType_UniB(30,280,30,"Times New Roman",1,400,0,0,0,"AD",pbuf,0, 0);//Byte Order Mark.

	        //barcode.
	        Z_Prn_Barcode(420, 100, 1, 2, 3, 40, '3', 1, "1234", 'N','Y','N','N','N');//have a counter
	        Z_Bar2d_QRCode(420, 190, 2, 3, 3, 1, "QR CODE", 0);

	        //picture.
            Z_Get_Graphic_ColorBMP(420, 280, 0, "bb.bmp");// Color bmp file to ram.
            Z_Get_Graphic_ColorBMPEx(420, 330, 200, 150, 2, 0, "bb1", "bb.bmp");//180 angle
            IntPtr himage = LoadImage(IntPtr.Zero, "bb.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
            Z_Get_Graphic_ColorBMP_HBitmap(630, 280, 250, 80, 1, 0, "bb2", himage);//90 angle.
            if (IntPtr.Zero != himage)
                DeleteObject(himage);

	        // output.
	        Z_Print_Out(2,1);// copy 2.

	        // close port.
	        Z_ClosePrn();
        }
    }
}